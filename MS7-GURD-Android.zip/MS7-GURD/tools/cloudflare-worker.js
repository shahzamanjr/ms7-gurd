/**
 * MS7 GURD — Cloudflare Worker
 * ----------------------------------------------------------
 * این اسکریپت لیست سرورهای اپ را از طریق Cloudflare تحویل می‌دهد.
 *
 * نصب (بدون دانش قبلی، ۵ دقیقه):
 * ۱) برو به dash.cloudflare.com  →  Workers & Pages  →  Create Worker
 * ۲) کل این فایل را در ادیتور کپی کن و Deploy بزن
 * ۳) در پایین همین فایل، آرایه SERVERS را با کانفیگ‌های خودت پر کن
 * ۴) آدرس ورکر (مثل https://ms7-config.YOUR-NAME.workers.dev) را
 *    در تنظیمات اپ، بخش «آدرس لیست سرورهای رسمی» وارد کن — تمام!
 *
 * مزیت: هر وقت کانفیگ‌ها را عوض کنی، کاربران بدون آپدیت اپ،
 * لیست جدید را می‌گیرند.
 */

const SERVERS = [
  {
    name: "آلمان ۱",
    country: "DE",
    uri: "vless://00000000-0000-0000-0000-000000000000@example.com:443?encryption=none&security=tls&sni=example.com&type=ws&path=%2Fpath#DE1"
  },
  {
    name: "آمریکا ۱",
    country: "US",
    uri: "vless://00000000-0000-0000-0000-000000000000@example2.com:443?encryption=none&security=tls&sni=example2.com&type=ws&path=%2Fpath#US1"
  }
  // ⬆️ سرورهای بیشتر را همین‌طور اضافه کن
];

export default {
  async fetch(request) {
    const url = new URL(request.url);

    // CORS برای هر درخواستی
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });

    // مسیرها
    if (url.pathname === "/" || url.pathname === "/servers") {
      const body = JSON.stringify({
        app: "MS7 GURD",
        developer: "مهدی شاه زمان",
        updated: new Date().toISOString().slice(0, 10),
        servers: SERVERS,
      }, null, 2);
      return new Response(body, {
        headers: { "Content-Type": "application/json; charset=utf-8", ...cors },
      });
    }

    // فرمت اشتراک استاندارد (base64) — برای برنامه‌هایی مثل v2rayNG هم کار می‌کند
    if (url.pathname === "/sub") {
      const text = SERVERS.map((s) => s.uri).join("\n");
      const b64 = btoa(unescape(encodeURIComponent(text)));
      return new Response(b64, {
        headers: { "Content-Type": "text/plain; charset=utf-8", ...cors },
      });
    }

    return new Response("MS7 GURD config API — made by مهدی شاه زمان", {
      headers: { "Content-Type": "text/plain; charset=utf-8", ...cors },
    });
  },
};
