# -*- coding: utf-8 -*-
"""
MS7 GURD — تولیدکننده کد فعال‌سازی پرمیوم
توسعه‌دهنده: مهدی شاه‌زمان

استفاده:
    python ms7_keygen.py                # یک کد ماهانه بساز
    python ms7_keygen.py --plan 1 -n 10 # ده کد سه‌ماهه بساز
    python ms7_keygen.py --plan 3       # کد مادام‌العمر

پلن‌ها: 0=ماهانه(۳۰روز) 1=سه‌ماهه(۹۰روز) 2=سالانه(۳۶۵روز) 3=مادام‌العمر

⚠️ اگر Salt را عوض می‌کنید، همین مقدار باید در
   app/src/main/java/ir/ms7gurd/vpn/data/Activation.kt هم عوض شود.
"""
import argparse
import hashlib
import random

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
SALT = "MS7-GURD-Mahdi-Shahzaman-2026"   # ← هماهنگ با Activation.kt
PLANS = ["ماهانه (۳۰ روز)", "سه‌ماهه (۹۰ روز)", "سالانه (۳۶۵ روز)", "مادام‌العمر"]


def checksum(payload14: str) -> str:
    d = hashlib.sha256((SALT + payload14).encode("utf-8")).digest()
    return ALPHABET[d[0] % len(ALPHABET)] + ALPHABET[d[1] % len(ALPHABET)]


def generate(plan: int) -> str:
    if plan < 0 or plan >= len(PLANS):
        raise ValueError("پلن باید ۰ تا ۳ باشد")
    tier_char = ALPHABET[plan]
    # ۱۳ کاراکتر تصادفی + کاراکتر پلن = ۱۴
    rnd = "".join(random.choice(ALPHABET) for _ in range(13))
    payload = tier_char + rnd
    code = "MS7-" + payload[:4] + "-" + payload[4:8] + "-" + payload[8:12] + "-" + payload[12:14] + checksum(payload)
    return code


def main():
    ap = argparse.ArgumentParser(description="MS7 GURD keygen — مهدی شاه‌زمان")
    ap.add_argument("--plan", type=int, default=0, help="0=ماهانه 1=سه‌ماهه 2=سالانه 3=مادام‌العمر")
    ap.add_argument("-n", "--count", type=int, default=1, help="تعداد کد")
    args = ap.parse_args()

    print(f"پلن: {PLANS[args.plan]}  |  تعداد: {args.count}")
    print("-" * 40)
    for _ in range(args.count):
        print(generate(args.plan))


if __name__ == "__main__":
    main()
