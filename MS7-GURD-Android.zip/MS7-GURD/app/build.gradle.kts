plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ir.ms7gurd.vpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.ms7gurd.vpn"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        vectorDrawables.useSupportLibrary = true
        // فقط معماری‌های واقعی گوشی‌ها (حجم APK نصف می‌شود؛ شبیه‌ساز x86 پشتیبانی نمی‌شود)
        ndk { abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a")) }
    }

    signingConfigs {
        create("release") {
            // امضا از طریق متغیرهای محیطی (GitHub Actions) — بیلد لوکال بدون امضا هم کار می‌کند
            val store = System.getenv("MS7_STORE_FILE")
            if (!store.isNullOrBlank() && file(store).exists()) {
                storeFile = file(store)
                storePassword = System.getenv("MS7_STORE_PASS")
                keyAlias = System.getenv("MS7_KEY_ALIAS")
                keyPassword = System.getenv("MS7_KEY_PASS")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (!System.getenv("MS7_STORE_FILE").isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += setOf("META-INF/*.kotlin_module", "META-INF/AL2.0", "META-INF/LGPL2.1")
    }
}

dependencies {
    // ---- AndroidX / Compose
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // ---- Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // ---- WireGuard core (official library, works out of the box)
    implementation("com.wireguard.android:tunnel:1.0.20251231")

    // ---- QR scanner (ML Kit on Google Maven)
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")

    // ---- هسته‌های اختیاری: برای فعال‌سازی Xray / OpenVPN فایل AAR را در پوشه app/libs بگذارید
    // implementation(files("libs/libv2ray.aar"))      // Xray core  → از مستندات README-FA.md
    // implementation(files("libs/OpenVPNLibrary.aar")) // OpenVPN core → از مستندات README-FA.md
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
}
