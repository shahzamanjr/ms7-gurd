# MS7 GURD proguard rules — Developer: Mahdi Shahzaman

# WireGuard
-keep class com.wireguard.** { *; }
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
-keepclassmembers class * extends com.sun.jna.** { public *; }

# Xray core (اختیاری — libv2ray.aar)
-keep class libv2ray.** { *; }
-keep class go.** { *; }
-keep class github.** { *; }
-dontwarn libv2ray.**
-dontwarn go.**

# OpenVPN core (اختیاری — OpenVPNLibrary.aar)
-keep class de.blinkt.openvpn.** { *; }
-dontwarn de.blinkt.openvpn.**

# ML Kit
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# Reflection-based optional engines
-keep class ir.ms7gurd.vpn.vpn.** { *; }

# Compose / Kotlin
-dontwarn org.jetbrains.annotations.**
-keepclassmembers class kotlin.Metadata { public <methods>; }
