package ir.ms7gurd.vpn.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.data.ConnState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * دکمه پاور درخشان — قلب طراحی MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
@Composable
fun GlowPowerButton(
    size: Dp,
    state: ConnState,
    teal: Color,
    blue: Color,
    onColor: Color,
    glowColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val infinite = rememberInfiniteTransition(label = "glow")
    val pulse by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Restart), label = "pulse",
    )
    val spin by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "spin",
    )

    val connected = state == ConnState.CONNECTED
    val connecting = state == ConnState.CONNECTING || state == ConnState.DISCONNECTING

    Box(
        modifier = modifier
            .size(size)
            .semantics { contentDescription = if (connected) "قطع اتصال" else "اتصال" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size)) {
            val cx = this.size.width / 2
            val cy = this.size.height / 2
            val outerR = this.size.minDimension / 2
            val ringR = outerR * 0.86f
            val innerR = outerR * 0.70f
            val active = connected || connecting

            // ---------- هاله‌های بیرونی (نئون) ----------
            val glowAlpha = if (active) (0.55f + 0.35f * pulse) else 0.18f + 0.08f * pulse
            val glowBrush = Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = glowAlpha * 0.55f), Color.Transparent),
                center = Offset(cx, cy),
                radius = outerR,
            )
            drawCircle(brush = glowBrush, radius = outerR, center = Offset(cx, cy))

            // حلقه درخشان اصلی
            drawCircle(
                brush = Brush.sweepGradient(listOf(blue, teal, blue), center = Offset(cx, cy)),
                radius = ringR,
                center = Offset(cx, cy),
                style = Stroke(width = outerR * (if (active) 0.055f else 0.04f)),
            )

            // حلقه نقطه‌چین ظریف (مثل نمونه طرح)
            if (active) {
                drawCircle(
                    color = teal.copy(alpha = 0.55f),
                    radius = ringR * 1.09f,
                    center = Offset(cx, cy),
                    style = Stroke(
                        width = outerR * 0.012f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(outerR * 0.035f, outerR * 0.05f)),
                    ),
                )
            }

            // ---------- حلقه چرخان هنگام اتصال ----------
            if (connecting) {
                rotate(degrees = spin, pivot = Offset(cx, cy)) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Color.Transparent, teal), center = Offset(cx, cy)),
                        startAngle = -90f, sweepAngle = 260f, useCenter = false,
                        topLeft = Offset(cx - ringR, cy - ringR),
                        size = androidx.compose.ui.geometry.Size(ringR * 2, ringR * 2),
                        style = Stroke(width = outerR * 0.05f, cap = StrokeCap.Round),
                    )
                }
            }

            // ---------- دایره داخلی ----------
            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (active)
                        listOf(onColor.copy(alpha = 0.16f), Color(0xFF0A1628).copy(alpha = 0.9f))
                    else
                        listOf(Color(0xFF10233D).copy(alpha = 0.85f), Color(0xFF081426).copy(alpha = 0.95f)),
                    center = Offset(cx, cy), radius = innerR,
                ),
                radius = innerR,
                center = Offset(cx, cy),
            )
            drawCircle(
                brush = Brush.linearGradient(listOf(blue.copy(alpha = if (active) 0.9f else 0.45f), teal.copy(alpha = if (active) 0.9f else 0.45f))),
                radius = innerR,
                center = Offset(cx, cy),
                style = Stroke(width = outerR * 0.028f),
            )

            // ---------- آیکون مرکزی ----------
            val iconR = innerR * 0.42f
            val stroke = iconR * 0.32f
            if (connected) {
                // تیک سبز بزرگ
                val p = Path().apply {
                    moveTo(cx - iconR * 0.75f, cy + iconR * 0.02f)
                    lineTo(cx - iconR * 0.15f, cy + iconR * 0.6f)
                    lineTo(cx + iconR * 0.85f, cy - iconR * 0.55f)
                }
                drawPath(p, color = teal, style = Stroke(width = stroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            } else {
                // آیکون پاور
                val pr = iconR * 0.78f
                // کمان بدنه
                drawArc(
                    color = if (connecting) teal.copy(alpha = 0.75f) else Color.White.copy(alpha = 0.95f),
                    startAngle = -55f, sweepAngle = 290f, useCenter = false,
                    topLeft = Offset(cx - pr, cy - pr),
                    size = androidx.compose.ui.geometry.Size(pr * 2, pr * 2),
                    style = Stroke(width = stroke * 0.9f, cap = StrokeCap.Round),
                )
                // خط عمودی
                drawLine(
                    color = if (connecting) teal.copy(alpha = 0.75f) else Color.White.copy(alpha = 0.95f),
                    start = Offset(cx, cy - pr - iconR * 0.35f),
                    end = Offset(cx, cy - pr * 0.18f),
                    strokeWidth = stroke * 0.9f,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}
