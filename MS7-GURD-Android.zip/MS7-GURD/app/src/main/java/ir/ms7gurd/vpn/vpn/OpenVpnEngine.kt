package ir.ms7gurd.vpn.vpn

import android.content.Context
import android.content.Intent
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.SplitConfig

/**
 * موتور OpenVPN (بتا) — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 *
 * با Reflection به هسته ics-openvpn (OpenVPNLibrary.aar) وصل می‌شود.
 * برای فعال‌سازی: فایل OpenVPNLibrary.aar را در پوشه app/libs بگذارید (README-FA.md بخش ۲).
 */
object OpenVpnEngine : VpnEngine {

    override val protocol = Protocol.OPENVPN

    private var appContext: Context? = null
    private var connected = false

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    override fun coreAvailable(): Boolean = try {
        Class.forName("de.blinkt.openvpn.core.ConfigParser") != null &&
            Class.forName("de.blinkt.openvpn.LaunchVPN") != null
    } catch (e: Throwable) {
        false
    }

    override suspend fun connect(server: Server, split: SplitConfig) {
        val ctx = appContext ?: throw InvalidConfigException("زمینه برنامه آماده نیست")
        if (!coreAvailable()) throw CoreMissingException("هسته OpenVPN (OpenVPNLibrary.aar)")

        try {
            // ۱) پارس کانفیگ
            val parserCls = Class.forName("de.blinkt.openvpn.core.ConfigParser")
            val parser = parserCls.getDeclaredConstructor().newInstance()
            val parseMethod = parserCls.methods.first { it.name == "parseConfig" }
            val reader = java.io.StringReader(server.config)
            try {
                parseMethod.invoke(parser, reader)
            } catch (e: java.lang.reflect.InvocationTargetException) {
                throw InvalidConfigException("کانفیگ OpenVPN نامعتبر است (${e.cause?.message ?: ""})")
            }

            val convertMethod = parserCls.methods.first { it.name == "convertProfile" }
            val profile = convertMethod.invoke(parser)

            // ۲) ثبت پروفایل موقت
            val pmCls = Class.forName("de.blinkt.openvpn.core.ProfileManager")
            try {
                val setTemp = pmCls.methods.first { it.name == "setTemporaryProfile" }
                setTemp.invoke(null, ctx, profile)
            } catch (e: Exception) {
                // نسخه‌های قدیمی‌تر: addProfile
                val add = pmCls.methods.firstOrNull { it.name == "addProfile" }
                add?.invoke(null, profile)
            }

            // ۳) اجرای اتصال (اکتیویتی LaunchVPN مجوز VPN را هم خودش مدیریت می‌کند)
            val launchCls = Class.forName("de.blinkt.openvpn.LaunchVPN")
            val intent = Intent(ctx, launchCls)
            val extraKey = launchCls.getField("EXTRA_KEY").get(null).toString()
            val extraName = launchCls.getField("EXTRA_NAME").get(null).toString()
            val extraHide = launchCls.getField("EXTRA_HIDELOG").get(null).toString()
            val uuidMethod = profile.javaClass.methods.firstOrNull { it.name == "getUUIDString" || it.name == "getUUID" || it.name == "getUuidString" }
            val uuid = try {
                uuidMethod?.invoke(profile)?.toString() ?: ""
            } catch (e: Exception) {
                try {
                    val f = profile.javaClass.getField("uuid")
                    f.get(profile)?.toString() ?: ""
                } catch (e2: Exception) { "" }
            }
            intent.putExtra(extraKey, uuid)
            intent.putExtra(extraName, "MS7 GURD — OpenVPN")
            intent.putExtra(extraHide, true)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)

            connected = true
        } catch (e: InvalidConfigException) {
            throw e
        } catch (e: CoreMissingException) {
            throw e
        } catch (e: Exception) {
            throw InvalidConfigException("اجرای OpenVPN ناموفق بود: ${e.message ?: ""}")
        }
    }

    override suspend fun disconnect() {
        val ctx = appContext ?: return
        try {
            val svcCls = Class.forName("de.blinkt.openvpn.core.OpenVPNService")
            // روش مطمئن: توقف سرویس (onDestroy → revoke → قطع تونل)
            ctx.stopService(Intent(ctx, svcCls))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        connected = false
    }

    override fun traffic(): Pair<Long, Long>? = if (!connected) null else try {
        // آمار لحظه‌ای در نسخه بتا پشتیبانی نمی‌شود
        null
    } catch (e: Exception) {
        null
    }

    override fun lastHandshake(): Long = if (connected) 1L else 0L
}
