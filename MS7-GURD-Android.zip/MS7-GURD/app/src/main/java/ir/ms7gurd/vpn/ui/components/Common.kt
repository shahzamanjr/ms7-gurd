package ir.ms7gurd.vpn.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.ms7gurd.vpn.R
import ir.ms7gurd.vpn.core.Consts
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * کامپوننت‌های مشترک — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */

@Composable
fun Ms7Card(
    modifier: Modifier = Modifier,
    contentColor: Color? = null,
    content: @Composable () -> Unit,
) {
    val p = Ms7Palette
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = contentColor ?: p.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Box(Modifier.padding(14.dp)) { content() }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, leadingDot: Boolean = true) {
    val p = Ms7Palette
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (leadingDot) {
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(p.teal)
            )
            Spacer(Modifier.width(7.dp))
        }
        Text(
            text,
            color = p.textDim,
            style = MaterialTheme.typography.labelLarge,
            letterSpacing = 1.5.sp,
        )
    }
}

@Composable
fun Ms7Switch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val p = Ms7Palette
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = p.teal,
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = p.outline,
            uncheckedBorderColor = Color.Transparent,
        ),
    )
}

@Composable
fun BadgeChip(text: String, color: Color, filled: Boolean = true) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (filled) color.copy(alpha = 0.16f) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text, color = color, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun PingBars(level: Int, color: Color, modifier: Modifier = Modifier) {
    // level: 1..4
    Row(modifier = modifier, verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        for (i in 1..4) {
            Box(
                Modifier
                    .size(width = 3.5.dp, height = (3 + i * 3).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (i <= level) color else color.copy(alpha = 0.22f))
            )
        }
    }
}

@Composable
fun StatCard(
    icon: ImageVector,
    title: String,
    value: String,
    sub: String,
    modifier: Modifier = Modifier,
) {
    val p = Ms7Palette
    Ms7Card(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.teal.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = p.textDim, style = MaterialTheme.typography.labelMedium)
                Text(value, color = p.text, style = MaterialTheme.typography.titleLarge)
                Text(sub, color = p.textDim, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

/** لوگوی هدر: سپر MS7 + نام برند + تگ‌لاین فارسی */
@Composable
fun Ms7LogoHeader(compact: Boolean = false) {
    val p = Ms7Palette
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.ic_ms7_shield),
            contentDescription = "MS7 GURD",
            modifier = Modifier.size(if (compact) 34.dp else 46.dp),
            contentScale = ContentScale.Fit,
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                Consts.APP_NAME,
                color = p.text,
                style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall,
                letterSpacing = 2.sp,
            )
            Text(
                Consts.TAGLINE,
                color = if (compact) p.textDim else p.teal,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.sp,
            )
        }
    }
}

/** کارت اطلاع‌رسانی ساده */
@Composable
fun TipCard(text: String, icon: ImageVector, modifier: Modifier = Modifier) {
    val p = Ms7Palette
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(p.teal.copy(alpha = 0.13f), p.blue.copy(alpha = 0.08f))))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(text, color = p.text, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Start)
        }
    }
}
