package ir.ms7gurd.vpn.data

import java.security.MessageDigest

/**
 * سیستم کد فعال‌سازی پرمیوم — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 *
 * فرمت کد: MS7-XXXX-XXXX-XXXX (۱۶ کاراکتر، بدون کاراکترهای گیج‌کننده)
 *  → کاراکتر ۱: نوع پلن (۰: ماهانه، ۱: ۳ ماهه، ۲: سالانه، ۳: مادام‌العمر)
 *  → کاراکترهای ۲ تا ۱۴: داده تصادفی
 *  → دو کاراکتر آخر: چک‌سام SHA-256
 *
 * ⚠️ ابزار تولید کد: tools/ms7_keygen.py  (در ریشه پروژه)
 */
object Activation {

    const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    /** پلن‌ها: [روزها، نام نمایشی] */
    val PLANS = listOf(
        30L to "پلن ماهانه",
        90L to "پلن سه‌ماهه",
        365L to "پلن سالانه",
        36500L to "پلن مادام‌العمر",
    )

    // Salt مخفی (XOR با 0x5A) — با tools/ms7_keygen.py هماهنگ است. اگر salt را عوض کردید، در keygen هم عوض کنید.
    private val SALT = intArrayOf(
        0x17, 0x09, 0x6D, 0x77, 0x1D, 0x0F, 0x08, 0x1E, 0x77, 0x17,
        0x3B, 0x32, 0x3E, 0x33, 0x77, 0x09, 0x32, 0x3B, 0x32, 0x20,
        0x3B, 0x37, 0x3B, 0x34, 0x77, 0x68, 0x6A, 0x68, 0x6C
    ).map { (it xor 0x5A).toChar() }.joinToString("")

    sealed class Result {
        data class Success(val days: Long, val planName: String) : Result()
        data class Error(val message: String) : Result()
    }

    fun validate(rawCode: String): Result {
        val code = rawCode.trim().uppercase().replace(" ", "").removePrefix("MS7-").replace("-", "")
        if (code.length != 16) return Result.Error("کد فعال‌سازی باید ۱۶ کاراکتر باشد")
        if (code.any { ALPHABET.indexOf(it) < 0 }) return Result.Error("کد فعال‌سازی حاوی کاراکتر نامعتبر است")

        val tier = ALPHABET.indexOf(code[0])
        if (tier >= PLANS.size) return Result.Error("نوع پلن در کد نامعتبر است")

        val payload = code.substring(0, 14)
        val given = code.substring(14, 16)
        val expected = checksum(payload)
        if (given != expected) return Result.Error("کد فعال‌سازی معتبر نیست")

        val (days, name) = PLANS[tier]
        return Result.Success(days, name)
    }

    /** چک‌سام دو کاراکتری — با keygen هماهنگ */
    fun checksum(payload14: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest((SALT + payload14).toByteArray(Charsets.UTF_8))
        val c1 = ALPHABET[(digest[0].toInt() and 0xFF) % ALPHABET.length]
        val c2 = ALPHABET[(digest[1].toInt() and 0xFF) % ALPHABET.length]
        return "$c1$c2"
    }
}
