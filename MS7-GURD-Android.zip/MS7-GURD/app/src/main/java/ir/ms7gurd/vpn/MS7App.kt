package ir.ms7gurd.vpn

import android.app.Application
import com.wireguard.android.backend.GoBackend
import ir.ms7gurd.vpn.data.SplitConfig
import ir.ms7gurd.vpn.data.ServerStore
import ir.ms7gurd.vpn.data.SettingsStore
import ir.ms7gurd.vpn.vpn.ConnectionManager
import ir.ms7gurd.vpn.vpn.OpenVpnEngine
import ir.ms7gurd.vpn.vpn.WireGuardEngine
import ir.ms7gurd.vpn.vpn.XrayEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * کلاس اپلیکیشن — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
class MS7App : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var settingsStore: SettingsStore
        private set
    lateinit var serverStore: ServerStore
        private set

    override fun onCreate() {
        super.onCreate()

        settingsStore = SettingsStore(this)
        serverStore = ServerStore(this)

        // اعلان‌ها
        ConnectionManager.init(this)

        // هسته WireGuard را از هم الان بارگذاری کن (نخ پس‌زمینه)
        appScope.launch(Dispatchers.IO) {
            WireGuardEngine.warmUp(applicationContext)
        }
        XrayEngine.init(this)
        OpenVpnEngine.init(this)

        // پشتیبانی از «همیشه روشن» سیستم (Always-On VPN)
        try {
            GoBackend.setAlwaysOnCallback {
                appScope.launch(Dispatchers.IO) {
                    try {
                        val settings = settingsStore.settings.first()
                        val all = serverStore.servers.first()
                        val server = all.firstOrNull { it.id == settings.selectedServerId } ?: all.firstOrNull()
                        if (server != null) {
                            ConnectionManager.connect(
                                applicationContext,
                                server,
                                SplitConfig(settings.splitMode, settings.splitApps)
                            )
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
