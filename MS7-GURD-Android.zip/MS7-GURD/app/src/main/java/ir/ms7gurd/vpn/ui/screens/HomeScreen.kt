package ir.ms7gurd.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.ms7gurd.vpn.core.Fa
import ir.ms7gurd.vpn.data.ConnState
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.components.FlagCircle
import ir.ms7gurd.vpn.ui.components.GlowPowerButton
import ir.ms7gurd.vpn.ui.components.Ms7Card
import ir.ms7gurd.vpn.ui.components.Ms7LogoHeader
import ir.ms7gurd.vpn.ui.components.PingBars
import ir.ms7gurd.vpn.ui.components.WorldMapBackground
import ir.ms7gurd.vpn.ui.nav.Routes
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * صفحه خانه — MS7 GURD (Developer: Mahdi Shahzaman)
 * طراحی مطابق نمونه: دکمه پاور درخشان + نقشه جهانی + آمار اتصال
 */
@Composable
fun HomeScreen(
    vm: MainViewModel,
    onGoServers: () -> Unit,
    onGoPremium: () -> Unit,
    onGoSettings: () -> Unit,
) {
    val p = Ms7Palette
    val conn by vm.connState.collectAsState()
    val servers by vm.servers.collectAsState()
    val settings by vm.settings.collectAsState()
    val premiumActive by vm.premiumActive.collectAsState()

    val selectedServer = servers.firstOrNull { it.id == settings.selectedServerId } ?: servers.firstOrNull()
    val connected = conn.state == ConnState.CONNECTED
    val connecting = conn.state == ConnState.CONNECTING || conn.state == ConnState.DISCONNECTING
    var showAboutPrivacy by remember { mutableStateOf(false) }

    val screenHeight = LocalConfiguration.current.screenHeightDp

    Box(
        Modifier
            .fillMaxSize()
            .background(p.bg)
    ) {
        // نقشه جهانی محو در پس‌زمینه
        WorldMapBackground(
            modifier = Modifier
                .fillMaxWidth()
                .height((screenHeight * 0.42f).dp)
                .align(Alignment.TopCenter),
            dotColor = p.textDim.copy(alpha = 0.10f),
            highlightColor = p.teal,
        )

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            // ---------------- هدر ----------------
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Ms7LogoHeader()
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(p.surface)
                        .clickable(onClick = onGoSettings),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = "تنظیمات", tint = p.textDim, modifier = Modifier.size(21.dp))
                }
            }

            Spacer(Modifier.height(6.dp))

            if (!premiumActive) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(p.gold.copy(alpha = 0.16f), p.teal.copy(alpha = 0.08f))))
                        .clickable(onClick = onGoPremium)
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.WorkspacePremium, contentDescription = null, tint = p.gold, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("ارتقا به پرمیوم — همه سرورها و سرعت نامحدود", color = p.text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = p.textDim, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // ---------------- دکمه پاور ----------------
            Spacer(Modifier.height((screenHeight * 0.035f).dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                GlowPowerButton(
                    size = (screenHeight * 0.30f).dp.coerceAtMost(290.dp),
                    state = conn.state,
                    teal = p.teal,
                    blue = p.blue,
                    onColor = p.surfaceHigh,
                    glowColor = if (connected) p.teal else p.blue,
                    onClick = { vm.toggleConnection() },
                )
            }
            Spacer(Modifier.height(14.dp))

            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when {
                        connected -> "متصل شدید"
                        connecting -> "در حال اتصال…"
                        conn.state == ConnState.FAILED -> "اتصال ناموفق"
                        else -> "متصل نیستید"
                    },
                    color = p.text,
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (connected) p.teal else p.textDim))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when {
                            connected -> "اتصال شما امن است"
                            connecting -> "لطفاً صبر کنید"
                            conn.state == ConnState.FAILED -> (conn.message ?: "قطع شده")
                            else -> "قطع شده"
                        },
                        color = if (connected) p.teal else p.textDim,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 1.sp,
                    )
                    if (connected) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = p.teal, modifier = Modifier.size(14.dp))
                    }
                }
            }

            // ---------------- آمار ----------------
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.Timer,
                    title = "زمان اتصال",
                    value = if (connected) Fa.timer(conn.elapsedSeconds) else "۰۰:۰۰:۰۰",
                    sub = "ساعت:دقیقه:ثانیه",
                )
                StatTile(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.Speed,
                    title = "سرعت",
                    value = if (connected) "${Fa.mbps(conn.downMbps)} مگابیت" else "—",
                    sub = "↓ ${Fa.mbps(conn.downMbps)}  ↑ ${Fa.mbps(conn.upMbps)}",
                )
            }

            // ---------------- کارت سرور ----------------
            Spacer(Modifier.height(12.dp))
            Ms7Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (selectedServer != null) {
                        FlagCircle(code = selectedServer.countryCode, size = 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (connected) "متصل به" else "سرور انتخابی",
                                color = p.textDim,
                                style = MaterialTheme.typography.labelSmall,
                            )
                            Text(
                                selectedServer.subtitle(),
                                color = p.text,
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    when (selectedServer.protocol) {
                                        Protocol.WIREGUARD -> "WireGuard"
                                        Protocol.XRAY -> "V2Ray / Xray"
                                        Protocol.OPENVPN -> "OpenVPN"
                                    },
                                    color = p.textDim, style = MaterialTheme.typography.labelSmall,
                                )
                                Spacer(Modifier.width(8.dp))
                                PingBars(level = pingLevel(vm.pingOf(selectedServer)), color = p.teal)
                            }
                        }
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (connected) p.teal else p.surfaceHigh)
                                .clickable(onClick = onGoServers),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (connected) Icons.Filled.Check else Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "تغییر سرور",
                                tint = if (connected) Color(0xFF06231F) else p.textDim,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    } else {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(p.surfaceHigh),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Shield, contentDescription = null, tint = p.textDim, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("هنوز سروری ندارید", color = p.text, style = MaterialTheme.typography.titleMedium)
                            Text("از تب «سرورها» کانفیگ اضافه کنید", color = p.textDim, style = MaterialTheme.typography.labelSmall)
                        }
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(p.teal.copy(alpha = 0.15f))
                                .clickable(onClick = onGoServers)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text("افزودن", color = p.teal, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            // ---------------- محافظت ----------------
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { showAboutPrivacy = true }
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = if (connected) p.teal else p.textDim, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("محافظت‌شده", color = p.text, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (connected) "آی‌پی شما مخفی است و ترافیک رمزنگاری می‌شود" else "برای محافظت کامل همین حالا وصل شوید",
                        color = p.textDim, style = MaterialTheme.typography.labelSmall,
                    )
                }
                Text("بیشتر بدانید", color = p.teal, style = MaterialTheme.typography.labelMedium)
            }

            Spacer(Modifier.height(24.dp))
        }

        // دیالوگ حریم خصوصی
        if (showAboutPrivacy) {
            AlertDialog(
                onDismissRequest = { showAboutPrivacy = false },
                title = { Text("چرا MS7 GURD؟") },
                text = {
                    Text(
                        "MS7 GURD اتصال شما را با رمزنگاری قوی AES-256 و پروتکل‌های WireGuard و V2Ray امن می‌کند. " +
                            "آی‌پی واقعی شما پنهان می‌ماند و هیچ لاگی از فعالیت شما نگه‌داری نمی‌شود. " +
                            "برای حداکثر امنیت، کیل‌سوئیچ را در تنظیمات روشن نگه دارید.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                },
                confirmButton = { TextButton(onClick = { showAboutPrivacy = false }) { Text("فهمیدم") } },
            )
        }
    }
}

@Composable
private fun StatTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    val p = Ms7Palette
    Ms7Card(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(p.teal.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = p.textDim, style = MaterialTheme.typography.labelSmall)
                Text(value, color = p.text, style = MaterialTheme.typography.titleLarge)
                Text(sub, color = p.textDim, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

fun pingLevel(pingMs: Int?): Int = when {
    pingMs == null -> 1
    pingMs < 60 -> 4
    pingMs < 120 -> 3
    pingMs < 250 -> 2
    else -> 1
}
