package ir.ms7gurd.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.core.Fa
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.components.BadgeChip
import ir.ms7gurd.vpn.ui.components.FlagCircle
import ir.ms7gurd.vpn.ui.components.Ms7Card
import ir.ms7gurd.vpn.ui.components.Ms7LogoHeader
import ir.ms7gurd.vpn.ui.components.PingBars
import ir.ms7gurd.vpn.ui.components.SectionTitle
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * صفحه سرورها — MS7 GURD (Developer: Mahdi Shahzaman)
 */
@Composable
fun ServersScreen(vm: MainViewModel, onAddConfig: () -> Unit) {
    val p = Ms7Palette
    val servers by vm.servers.collectAsState()
    val settings by vm.settings.collectAsState()
    val premiumActive by vm.premiumActive.collectAsState()
    val pinging by vm.pinging.collectAsState()
    var query by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<Server?>(null) }

    val filtered = servers.filter {
        query.isBlank() || it.name.contains(query, true) || it.city.contains(query, true) || it.country.contains(query, true)
    }
    val recommended = filtered.filter { vm.pingOf(it) != null }.sortedBy { vm.pingOf(it) }.take(2)
    val rest = filtered.filterNot { recommended.contains(it) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Ms7LogoHeader(compact = true)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.gold.copy(alpha = if (premiumActive) 0.18f else 0.10f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    if (premiumActive) "پرمیوم فعال" else "پرمیوم",
                    color = p.gold,
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // جستجو
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(p.surface)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = p.textDim, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                androidx.compose.material3.TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("جستجوی کشور یا شهر…", color = p.textDim, style = MaterialTheme.typography.bodyMedium) },
                    singleLine = true,
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = p.teal,
                        focusedTextColor = p.text,
                        unfocusedTextColor = p.text,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(if (pinging) p.textDim.copy(alpha = 0.2f) else p.teal.copy(alpha = 0.15f))
                        .clickable { if (!pinging) vm.pingAll() }
                        .padding(6.dp)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "تست پینگ", tint = if (pinging) p.textDim else p.teal, modifier = Modifier.size(18.dp))
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // دکمه افزودن
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(p.teal.copy(alpha = 0.13f))
                .clickable(onClick = onAddConfig)
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = p.teal, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("افزودن کانفیگ (متن، QR، سابسکریپشن)", color = p.teal, style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(14.dp))

        if (filtered.isEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 60.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = p.textDim.copy(alpha = 0.5f), modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(10.dp))
                Text("هنوز سروری نیست", color = p.textDim, style = MaterialTheme.typography.titleMedium)
                Text("دکمه بالا را بزنید و کانفیگ خود را اضافه کنید", color = p.textDim, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (recommended.isNotEmpty()) {
                    item { SectionTitle("پیشنهادی") }
                    items(recommended, key = { it.id }) { ServerRow(vm, it, settings.selectedServerId, premiumActive, onLongPress = { pendingDelete = it }) }
                }
                if (rest.isNotEmpty()) {
                    item { SectionTitle("همه سرورها") }
                    items(rest, key = { it.id }) { ServerRow(vm, it, settings.selectedServerId, premiumActive, onLongPress = { pendingDelete = it }) }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }

    // دیالوگ حذف
    pendingDelete?.let { server ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("حذف سرور") },
            text = { Text("«${server.name}» حذف شود؟") },
            confirmButton = {
                TextButton(onClick = { vm.deleteServer(server); pendingDelete = null }) { Text("حذف", color = p.danger) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("انصراف") } },
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ServerRow(
    vm: MainViewModel,
    server: Server,
    selectedId: String,
    premiumActive: Boolean,
    onLongPress: (Server) -> Unit,
) {
    val p = Ms7Palette
    val isSelected = server.id == selectedId
    val locked = server.premium && !premiumActive
    val ping = vm.pingOf(server)

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) p.teal.copy(alpha = 0.10f) else p.surface)
            .combinedClickable(
                onClick = { vm.selectServer(server) },
                onLongClick = { onLongPress(server) },
            )
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
                FlagCircle(code = server.countryCode, size = 40.dp)
                if (server.premium) {
                    Icon(
                        Icons.Filled.WorkspacePremium,
                        contentDescription = "پرمیوم",
                        tint = p.gold,
                        modifier = Modifier
                            .size(15.dp)
                            .align(Alignment.TopEnd),
                    )
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (locked) server.name else server.subtitle(),
                        color = if (locked) p.textDim else p.text,
                        style = MaterialTheme.typography.titleSmall,
                    )
                    if (server.badge != null) {
                        Spacer(Modifier.width(6.dp))
                        BadgeChip(server.badge, p.teal)
                    }
                    if (locked) {
                        Spacer(Modifier.width(6.dp))
                        BadgeChip("پرمیوم", p.gold)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (server.protocol) {
                            Protocol.WIREGUARD -> "WireGuard"
                            Protocol.XRAY -> "Xray"
                            Protocol.OPENVPN -> "OpenVPN"
                        },
                        color = p.textDim, style = MaterialTheme.typography.labelSmall,
                    )
                    if (server.city.isNotBlank() && !locked) {
                        Text(" • ${server.city}", color = p.textDim, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                if (ping != null) {
                    Text(Fa.num(ping), color = p.teal, style = MaterialTheme.typography.titleSmall)
                } else {
                    Text("—", color = p.textDim, style = MaterialTheme.typography.titleSmall)
                }
                Spacer(Modifier.height(3.dp))
                PingBars(level = pingLevel(ping), color = p.teal)
            }
        }
    }
}
