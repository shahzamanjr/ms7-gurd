package ir.ms7gurd.vpn.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import ir.ms7gurd.vpn.data.ThemeMode

/**
 * تم MS7 GURD — دو تم کامل تیره/روشن
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */

data class Ms7Colors(
    val bg: Color,
    val bgSoft: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val outline: Color,
    val text: Color,
    val textDim: Color,
    val teal: Color,
    val blue: Color,
    val gold: Color,
    val danger: Color,
)

val LocalMs7Colors = staticCompositionLocalOf {
    Ms7Colors(DarkBg, DarkBgSoft, DarkSurface, DarkSurfaceHigh, DarkOutline, DarkText, DarkTextDim, DarkAccentTeal, DarkAccentBlue, DarkGold, DarkDanger)
}

private val DarkPalette = Ms7Colors(
    bg = DarkBg, bgSoft = DarkBgSoft, surface = DarkSurface, surfaceHigh = DarkSurfaceHigh,
    outline = DarkOutline, text = DarkText, textDim = DarkTextDim,
    teal = DarkAccentTeal, blue = DarkAccentBlue, gold = DarkGold, danger = DarkDanger,
)

private val LightPalette = Ms7Colors(
    bg = LightBg, bgSoft = LightBgSoft, surface = LightSurface, surfaceHigh = LightSurfaceHigh,
    outline = LightOutline, text = LightText, textDim = LightTextDim,
    teal = LightAccentTeal, blue = LightAccentBlue, gold = LightGold, danger = LightDanger,
)

private val DarkScheme = darkColorScheme(
    primary = DarkAccentTeal,
    secondary = DarkAccentBlue,
    tertiary = DarkGold,
    background = DarkBg,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceHigh,
    outline = DarkOutline,
    onPrimary = Color(0xFF06231F),
    onBackground = DarkText,
    onSurface = DarkText,
    error = DarkDanger,
)

private val LightScheme = lightColorScheme(
    primary = LightAccentTeal,
    secondary = LightAccentBlue,
    tertiary = LightGold,
    background = LightBg,
    surface = LightSurface,
    surfaceVariant = LightSurfaceHigh,
    outline = LightOutline,
    onPrimary = Color.White,
    onBackground = LightText,
    onSurface = LightText,
    error = LightDanger,
)

/** متغیرهای رنگ برند برای استفاده راحت در کامپوننت‌ها */
val Ms7Palette: Ms7Colors
    @Composable get() = LocalMs7Colors.current

@Composable
fun Ms7Theme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val palette = if (dark) DarkPalette else LightPalette

    androidx.compose.runtime.CompositionLocalProvider(LocalMs7Colors provides palette) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = Ms7Typography,
            content = content,
        )
    }
}
