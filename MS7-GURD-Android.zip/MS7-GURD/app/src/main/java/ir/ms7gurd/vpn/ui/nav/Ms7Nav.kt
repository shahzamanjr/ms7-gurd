package ir.ms7gurd.vpn.ui.nav

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.screens.AddConfigScreen
import ir.ms7gurd.vpn.ui.screens.HomeScreen
import ir.ms7gurd.vpn.ui.screens.PremiumScreen
import ir.ms7gurd.vpn.ui.screens.SettingsScreen
import ir.ms7gurd.vpn.ui.screens.ServersScreen
import ir.ms7gurd.vpn.ui.screens.SplitTunnelScreen
import ir.ms7gurd.vpn.ui.screens.SupportScreen
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * ناوبری اصلی — MS7 GURD (Developer: Mahdi Shahzaman)
 */

object Routes {
    const val HOME = "home"
    const val SERVERS = "servers"
    const val PREMIUM = "premium"
    const val SETTINGS = "settings"
    const val SUPPORT = "support"
    const val ADD_CONFIG = "addconfig"
    const val SPLIT_TUNNEL = "splittunnel"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector, val gold: Boolean = false)

private val tabs = listOf(
    Tab(Routes.HOME, "خانه", Icons.Filled.Home),
    Tab(Routes.SERVERS, "سرورها", Icons.Outlined.Public),
    Tab(Routes.PREMIUM, "پرمیوم", Icons.Filled.WorkspacePremium, gold = true),
    Tab(Routes.SETTINGS, "تنظیمات", Icons.Filled.Settings),
    Tab(Routes.SUPPORT, "پشتیبانی", Icons.Filled.SupportAgent),
)

@Composable
fun Ms7App(vm: MainViewModel) {
    val nav = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    // مجوز VPN سیستم
    val vpnPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.onVpnPermissionResult()
    }

    // پیام‌های Snackbar
    LaunchedEffect(Unit) {
        vm.snackbar.collect { msg ->
            if (msg != null) {
                snackbarHostState.showSnackbar(msg)
                vm.clearSnackbar()
            }
        }
    }

    // درخواست مجوز VPN
    LaunchedEffect(Unit) {
        vm.vpnRequest.collect { intent ->
            if (intent != null) {
                vpnPermissionLauncher.launch(intent)
                vm.clearVpnRequest()
            }
        }
    }

    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = currentRoute in tabs.map { it.route }

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            enterTransition = { fadeIn() },
            exitTransition = { fadeOut() },
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    vm = vm,
                    onGoServers = { nav.navigate(Routes.SERVERS) },
                    onGoPremium = { nav.navigate(Routes.PREMIUM) },
                    onGoSettings = { nav.navigate(Routes.SETTINGS) },
                )
            }
            composable(Routes.SERVERS) {
                ServersScreen(
                    vm = vm,
                    onAddConfig = { nav.navigate(Routes.ADD_CONFIG) },
                )
            }
            composable(Routes.PREMIUM) { PremiumScreen(vm = vm) }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    vm = vm,
                    onOpenSplitTunnel = { nav.navigate(Routes.SPLIT_TUNNEL) },
                )
            }
            composable(Routes.SUPPORT) { SupportScreen(vm = vm) }
            composable(Routes.ADD_CONFIG) { AddConfigScreen(vm = vm, onBack = { nav.popBackStack() }) }
            composable(Routes.SPLIT_TUNNEL) { SplitTunnelScreen(vm = vm, onBack = { nav.popBackStack() }) }
        }

        if (showBottomBar) {
            BottomBar(nav = nav, currentRoute = currentRoute, modifier = Modifier.align(Alignment.BottomCenter))
        }

        // Snackbar
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (showBottomBar) 96.dp else 24.dp)
        ) {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = Ms7Palette.surfaceHigh,
                    contentColor = Ms7Palette.text,
                )
            }
        }
    }
}

@Composable
private fun BottomBar(nav: NavHostController, currentRoute: String?, modifier: Modifier = Modifier) {
    val p = Ms7Palette
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .navigationBarsPadding()
            .padding(bottom = 8.dp)
            .shadow(12.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(p.surface.copy(alpha = 0.97f))
            .padding(vertical = 8.dp),
    ) {
        tabs.forEach { tab ->
            val selected = currentRoute == tab.route
            val tint = when {
                tab.gold && selected -> p.gold
                tab.gold -> p.gold.copy(alpha = 0.8f)
                selected -> p.teal
                else -> p.textDim
            }
            Column(
                Modifier
                    .weight(1f)
                    .selectable(selected = selected, onClick = {
                        if (currentRoute != tab.route) {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    })
                    .padding(vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(tab.icon, contentDescription = tab.label, tint = tint, modifier = Modifier.size(23.dp))
                Text(tab.label, color = tint, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
