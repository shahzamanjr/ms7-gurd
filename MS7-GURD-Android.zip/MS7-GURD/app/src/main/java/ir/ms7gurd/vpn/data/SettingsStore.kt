package ir.ms7gurd.vpn.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "ms7_settings")

/**
 * تنظیمات اپ — MS7 GURD (Developer: Mahdi Shahzaman)
 */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val autoConnect: Boolean = false,
    val killSwitch: Boolean = true,
    val notifications: Boolean = true,
    val splitMode: SplitMode = SplitMode.NONE,
    val splitApps: Set<String> = emptySet(),
    val premiumUntilEpochDay: Long = 0,
    val premiumPlan: String = "",
    val selectedServerId: String = "",
)

class SettingsStore(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme_mode")
        val autoConnect = booleanPreferencesKey("auto_connect")
        val killSwitch = booleanPreferencesKey("kill_switch")
        val notifications = booleanPreferencesKey("notifications")
        val splitMode = stringPreferencesKey("split_mode")
        val splitApps = stringSetPreferencesKey("split_apps")
        val premiumUntil = longPreferencesKey("premium_until_epoch_day")
        val premiumPlan = stringPreferencesKey("premium_plan")
        val selectedServer = stringPreferencesKey("selected_server_id")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { p ->
        AppSettings(
            themeMode = ThemeMode.entries.firstOrNull { it.name == p[K.theme] } ?: ThemeMode.SYSTEM,
            autoConnect = p[K.autoConnect] ?: false,
            killSwitch = p[K.killSwitch] ?: true,
            notifications = p[K.notifications] ?: true,
            splitMode = SplitMode.entries.firstOrNull { it.name == p[K.splitMode] } ?: SplitMode.NONE,
            splitApps = p[K.splitApps] ?: emptySet(),
            premiumUntilEpochDay = p[K.premiumUntil] ?: 0L,
            premiumPlan = p[K.premiumPlan] ?: "",
            selectedServerId = p[K.selectedServer] ?: "",
        )
    }

    suspend fun setTheme(mode: ThemeMode) = context.settingsDataStore.edit { it[K.theme] = mode.name }
    suspend fun setAutoConnect(v: Boolean) = context.settingsDataStore.edit { it[K.autoConnect] = v }
    suspend fun setKillSwitch(v: Boolean) = context.settingsDataStore.edit { it[K.killSwitch] = v }
    suspend fun setNotifications(v: Boolean) = context.settingsDataStore.edit { it[K.notifications] = v }
    suspend fun setSplitMode(mode: SplitMode) = context.settingsDataStore.edit { it[K.splitMode] = mode.name }
    suspend fun setSplitApps(apps: Set<String>) = context.settingsDataStore.edit { it[K.splitApps] = apps }
    suspend fun setSelectedServer(id: String) = context.settingsDataStore.edit { it[K.selectedServer] = id }

    suspend fun activatePremium(days: Long, plan: String) = context.settingsDataStore.edit {
        val today = java.time.LocalDate.now().toEpochDay()
        val current = (it[K.premiumUntil] ?: 0L).coerceAtLeast(today)
        it[K.premiumUntil] = current + days
        it[K.premiumPlan] = plan
    }

    /** فعال‌سازی مجدد از همان کد → تاریخ جدید از امروز محاسبه می‌شود */
    suspend fun resetPremium() = context.settingsDataStore.edit {
        it[K.premiumUntil] = 0L
        it[K.premiumPlan] = ""
    }
}
