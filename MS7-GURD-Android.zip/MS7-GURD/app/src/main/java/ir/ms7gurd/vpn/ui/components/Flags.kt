package ir.ms7gurd.vpn.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.ms7gurd.vpn.ui.theme.Vazirmatn

/**
 * پرچم گرد کشورها — بدون emoji (سازگار با همه گوشی‌ها)
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */

private val US_BLUE = Color(0xFF3C3B6E)
private val US_RED = Color(0xFFB22234)
private val WHITE = Color(0xFFFFFFFF)

@Composable
fun FlagCircle(code: String, size: Dp, modifier: Modifier = Modifier) {
    val textMeasurer = rememberTextMeasurer()
    Canvas(modifier = modifier.size(size)) {
        val r = this.size.minDimension / 2f
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val clip = Path().apply { addOval(androidx.compose.ui.geometry.Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }

        clipPath(clip) {
            when (code.uppercase()) {
                "US" -> usFlag()
                "UK" -> ukFlag()
                "DE" -> stripesH(listOf(Color(0xFF000000), Color(0xFFDD0000), Color(0xFFFFCE00)))
                "FR" -> stripesV(listOf(Color(0xFF0055A4), WHITE, Color(0xFFEF4135)))
                "IT" -> stripesV(listOf(Color(0xFF009246), WHITE, Color(0xFFCE2B37)))
                "NL" -> stripesH(listOf(Color(0xFFAE1C28), WHITE, Color(0xFF21468B)))
                "RU" -> stripesH(listOf(WHITE, Color(0xFF0039A6), Color(0xFFD52B1E)))
                "AT" -> stripesH(listOf(Color(0xFFED2939), WHITE, Color(0xFFED2939)))
                "HU" -> stripesH(listOf(Color(0xFFCE2939), WHITE, Color(0xFF477050)))
                "BG" -> stripesH(listOf(WHITE, Color(0xFF00966E), Color(0xFFD62612)))
                "EE" -> stripesH(listOf(Color(0xFF0072CE), Color(0xFF000000), WHITE))
                "LT" -> stripesH(listOf(Color(0xFFFDB913), Color(0xFF006A44), Color(0xFFC1272D)))
                "CA" -> canada()
                "JP" -> japan()
                "KR" -> korea()
                "SG" -> singapore()
                "IN" -> india()
                "TR" -> turkey()
                "AE" -> uae()
                "FI" -> nordicCross(Color(0xFF003580), WHITE)
                "SE" -> nordicCross(Color(0xFF006AA7), Color(0xFFFECC02))
                "NO" -> nordicCross(Color(0xFFBA0C2F), WHITE, inner = Color(0xFF00205B))
                "DK" -> nordicCross(Color(0xFFC8102E), WHITE)
                "CH" -> swiss()
                "AU" -> australia()
                "UA" -> stripesH(listOf(Color(0xFF005BBB), Color(0xFFFFD500)))
                "PL" -> stripesH(listOf(WHITE, Color(0xFFDC143C)))
                "BR" -> brazil()
                "IN2" -> india()
                else -> fallback(code.uppercase(), textMeasurer)
            }
        }
        // حلقه ظریف دور پرچم
        drawCircle(color = Color.White.copy(alpha = 0.22f), radius = r - 0.75.dp.toPx(), center = c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
    }
}

// ---------- پرچم‌ها ----------
private fun DrawScope.fullRect(color: Color) = drawRect(color, size = size)

private fun DrawScope.stripesH(colors: List<Color>) {
    val h = size.height / colors.size
    colors.forEachIndexed { i, c -> drawRect(c, topLeft = Offset(0f, i * h), size = Size(size.width, h + 1f)) }
}

private fun DrawScope.stripesV(colors: List<Color>) {
    val w = size.width / colors.size
    colors.forEachIndexed { i, c -> drawRect(c, topLeft = Offset(i * w, 0f), size = Size(w + 1f, size.height)) }
}

private fun DrawScope.usFlag() {
    stripesH(List(7) { if (it % 2 == 0) US_RED else WHITE })
    drawRect(US_BLUE, size = Size(size.width * 0.48f, size.height * 0.55f))
    // ستاره‌ها به صورت نقطه‌های سفید
    val dotR = size.width * 0.018f
    for (row in 0..2) for (col in 0..3) {
        drawCircle(WHITE, dotR, Offset(size.width * (0.08f + col * 0.11f), size.height * (0.12f + row * 0.17f)))
    }
}

private fun DrawScope.ukFlag() {
    fullRect(Color(0xFF012169))
    val w = size.width; val h = size.height
    val diag = Path().apply {
        moveTo(0f, 0f); lineTo(w, h); moveTo(w, 0f); lineTo(0f, h)
    }
    drawPath(diag, WHITE, style = androidx.compose.ui.graphics.drawscope.Stroke(w * 0.14f))
    drawPath(diag, Color(0xFFC8102E), style = androidx.compose.ui.graphics.drawscope.Stroke(w * 0.06f))
    drawRect(WHITE, topLeft = Offset(w * 0.4f, 0f), size = Size(w * 0.2f, h))
    drawRect(WHITE, topLeft = Offset(0f, h * 0.4f), size = Size(w, h * 0.2f))
    drawRect(Color(0xFFC8102E), topLeft = Offset(w * 0.44f, 0f), size = Size(w * 0.12f, h))
    drawRect(Color(0xFFC8102E), topLeft = Offset(0f, h * 0.44f), size = Size(w, h * 0.12f))
}

private fun DrawScope.canada() {
    stripesV(listOf(Color(0xFFD80621), WHITE, Color(0xFFD80621)))
    // برگه افرا ساده: لوزی قرمز وسط
    val c = Offset(size.width / 2f, size.height / 2f)
    val s = size.height * 0.28f
    val leaf = Path().apply {
        moveTo(c.x, c.y - s); lineTo(c.x + s * 0.55f, c.y)
        lineTo(c.x + s * 0.2f, c.y + s * 0.15f); lineTo(c.x, c.y + s * 0.9f)
        lineTo(c.x - s * 0.2f, c.y + s * 0.15f); lineTo(c.x - s * 0.55f, c.y); close()
    }
    drawPath(leaf, Color(0xFFD80621))
}

private fun DrawScope.japan() {
    fullRect(WHITE)
    drawCircle(Color(0xFFBC002D), size.height * 0.24f, Offset(size.width / 2f, size.height / 2f))
}

private fun DrawScope.korea() {
    fullRect(WHITE)
    drawCircle(Color(0xFFCD2E3A), size.height * 0.22f, Offset(size.width / 2f, size.height / 2f - size.height * 0.1f))
    drawCircle(Color(0xFF0047A0), size.height * 0.22f, Offset(size.width / 2f, size.height / 2f + size.height * 0.1f))
    drawRect(Color(0xFFCD2E3A), topLeft = Offset(size.width / 2f - size.height * 0.22f, size.height / 2f - size.height * 0.1f), size = Size(size.height * 0.44f, size.height * 0.1f))
    drawRect(Color(0xFF0047A0), topLeft = Offset(size.width / 2f - size.height * 0.22f, size.height / 2f), size = Size(size.height * 0.44f, size.height * 0.1f))
}

private fun DrawScope.singapore() {
    stripesH(listOf(Color(0xFFEF3340), WHITE))
    drawCircle(WHITE, size.height * 0.16f, Offset(size.width * 0.3f, size.height * 0.25f))
    drawCircle(Color(0xFFEF3340), size.height * 0.135f, Offset(size.width * 0.36f, size.height * 0.24f))
}

private fun DrawScope.india() {
    stripesH(listOf(Color(0xFFFF9933), WHITE, Color(0xFF138808)))
    drawCircle(Color(0xFF000080), size.height * 0.11f, Offset(size.width / 2f, size.height / 2f), style = androidx.compose.ui.graphics.drawscope.Stroke(size.width * 0.02f))
}

private fun DrawScope.turkey() {
    fullRect(Color(0xFFE30A17))
    val cy = size.height / 2f
    drawCircle(WHITE, size.height * 0.22f, Offset(size.width * 0.4f, cy))
    drawCircle(Color(0xFFE30A17), size.height * 0.175f, Offset(size.width * 0.45f, cy))
    drawCircle(WHITE, size.height * 0.05f, Offset(size.width * 0.62f, cy))
}

private fun DrawScope.uae() {
    stripesH(listOf(Color(0xFF00732F), WHITE, Color(0xFF000000)))
    drawRect(Color(0xFFFF0000), size = Size(size.width * 0.28f, size.height))
}

private fun DrawScope.nordicCross(base: Color, cross: Color, inner: Color? = null) {
    fullRect(base)
    val w = size.width; val h = size.height
    drawRect(cross, topLeft = Offset(w * 0.26f, 0f), size = Size(w * 0.16f, h))
    drawRect(cross, topLeft = Offset(0f, h * 0.42f), size = Size(w, h * 0.16f))
    if (inner != null) {
        drawRect(inner, topLeft = Offset(w * 0.29f, 0f), size = Size(w * 0.10f, h))
        drawRect(inner, topLeft = Offset(0f, h * 0.45f), size = Size(w, h * 0.10f))
    }
}

private fun DrawScope.swiss() {
    fullRect(Color(0xFFDA291C))
    val c = Offset(size.width / 2f, size.height / 2f)
    val t = size.height * 0.17f
    drawRect(WHITE, topLeft = Offset(c.x - t, c.y - t * 2.6f), size = Size(t * 2, t * 5.2f))
    drawRect(WHITE, topLeft = Offset(c.x - t * 2.6f, c.y - t), size = Size(t * 5.2f, t * 2))
}

private fun DrawScope.australia() {
    fullRect(Color(0xFF012169))
    // صلیب اتحاد کوچک بالا-چپ
    val w = size.width * 0.5f; val h = size.height * 0.5f
    drawRect(WHITE, topLeft = Offset(w * 0.36f, 0f), size = Size(w * 0.18f, h))
    drawRect(WHITE, topLeft = Offset(0f, h * 0.36f), size = Size(w, h * 0.18f))
    drawRect(Color(0xFFC8102E), topLeft = Offset(w * 0.40f, 0f), size = Size(w * 0.10f, h))
    drawRect(Color(0xFFC8102E), topLeft = Offset(0f, h * 0.40f), size = Size(w, h * 0.10f))
    // ستاره‌ها
    val dotR = size.width * 0.035f
    drawCircle(WHITE, dotR, Offset(size.width * 0.75f, size.height * 0.72f))
    drawCircle(WHITE, dotR, Offset(size.width * 0.68f, size.height * 0.5f))
    drawCircle(WHITE, dotR, Offset(size.width * 0.82f, size.height * 0.55f))
    drawCircle(WHITE, dotR, Offset(size.width * 0.75f, size.height * 0.32f))
    drawCircle(WHITE, dotR, Offset(size.width * 0.86f, size.height * 0.88f))
}

private fun DrawScope.brazil() {
    fullRect(Color(0xFF009C3B))
    val c = Offset(size.width / 2f, size.height / 2f)
    val d = Path().apply {
        moveTo(c.x, c.y - size.height * 0.3f)
        lineTo(c.x + size.width * 0.36f, c.y)
        lineTo(c.x, c.y + size.height * 0.3f)
        lineTo(c.x - size.width * 0.36f, c.y)
        close()
    }
    drawPath(d, Color(0xFFFFDF00))
    drawCircle(Color(0xFF002776), size.height * 0.14f, c)
}

private fun DrawScope.fallback(code: String, textMeasurer: androidx.compose.ui.text.TextMeasurer) {
    drawRect(
        Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF2DD4BF))),
        size = size,
    )
    if (code.length >= 2) {
        val style = TextStyle(fontFamily = Vazirmatn, fontSize = (size.height * 0.42f).sp, color = WHITE)
        val layout = textMeasurer.measure(code.take(2), style)
        drawText(layout, topLeft = Offset(size.width / 2f - layout.size.width / 2f, size.height / 2f - layout.size.height / 2f))
    }
}
