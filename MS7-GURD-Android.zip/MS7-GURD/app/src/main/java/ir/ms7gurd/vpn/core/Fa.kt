package ir.ms7gurd.vpn.core

import java.util.Locale
import kotlin.math.abs

/**
 * ابزارهای فارسی‌سازی اعداد و تاریخ — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
object Fa {

    private val digits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    /** تبدیل عدد به رقم فارسی */
    fun num(n: Long): String = n.toString().map { if (it.isDigit()) digits[it - '0'] else it }.joinToString("")
    fun num(n: Int): String = num(n.toLong())

    fun numDecimal(n: Double, fraction: Int = 1): String {
        val s = String.format(Locale.US, "%.${fraction}f", n)
        return s.map { if (it.isDigit()) digits[it - '0'] else if (it == '.') '٫' else it }.joinToString("")
    }

    /** 00:25:48 → ۰۰:۲۵:۴۸ */
    fun timer(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return "%02d:%02d:%02d".format(Locale.US, h, m, s).map { if (it.isDigit()) digits[it - '0'] else it }.joinToString("")
    }

    /** بایت → «۲.۳ مگابایت» */
    fun bytes(b: Long): String {
        val v = abs(b.toDouble())
        return when {
            v >= 1_073_741_824 -> "${numDecimal(b / 1_073_741_824.0)} گیگابایت"
            v >= 1_048_576 -> "${numDecimal(b / 1_048_576.0)} مگابایت"
            v >= 1024 -> "${numDecimal(b / 1024.0)} کیلوبایت"
            else -> "${num(b)} بایت"
        }
    }

    /** مگابیت بر ثانیه */
    fun mbps(v: Double): String = numDecimal(v, if (v >= 100) 0 else 1)

    fun ping(ms: Int): String = "${num(ms)} میلی‌ثانیه"

    fun date(epochDay: Long): String {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Tehran"))
        cal.timeInMillis = epochDay * 86_400_000L
        val jd = solarDate(cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1, cal.get(java.util.Calendar.DAY_OF_MONTH))
        return "${num(jd.first)}/${num(jd.second)}/${num(jd.third)}"
    }

    /** میلادی → شمسی */
    fun solarDate(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val g_d_m = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var jy = if (gy > 1600) 979 else 0
        var y = if (gy > 1600) gy - 1600 else gy - 621
        val gd2 = if (gm > 2 && ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0)) gd + 1 else gd
        jy += 365 * y + (y + 3) / 4 - (y + 99) / 100 + (y + 399) / 400 - 80 + g_d_m[gm - 1] + gd2
        y = jy / 1461
        var j = jy % 1461
        jy = if (j >= 2296) y + y / 33 * 8 + (j - 2296) / 366 else y
        j = if (j >= 2296) (j - 2296) % 366 + 366 else j % 366 + 1
        var jm: Int
        var jd: Int
        if (j <= 186) { jm = 1 + (j - 1) / 31; jd = j - (jm - 1) * 31 }
        else { jm = 7 + (j - 187) / 30; jd = j - 186 - (jm - 7) * 30 }
        return Triple(jy, jm, jd)
    }
}
