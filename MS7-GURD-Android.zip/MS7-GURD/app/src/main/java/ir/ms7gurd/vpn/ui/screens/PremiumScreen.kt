package ir.ms7gurd.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.core.Consts
import ir.ms7gurd.vpn.data.Activation
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.components.Ms7LogoHeader
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * صفحه پرمیوم — MS7 GURD (Developer: Mahdi Shahzaman)
 * طراحی مطابق نمونه + فعال‌سازی با کد
 */
@Composable
fun PremiumScreen(vm: MainViewModel) {
    val p = Ms7Palette
    val premiumActive by vm.premiumActive.collectAsState()
    val untilText by vm.premiumUntilText.collectAsState()
    var selectedPlan by remember { mutableStateOf(1) } // سالانه پیش‌فرض
    var showCodeDialog by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }

    val plans = listOf(
        Triple("ماهانه", "ماهیانه ساده", Consts.PRICE_MONTHLY),
        Triple("سالانه", "پرفروش‌ترین • به‌صرفه‌تر", Consts.PRICE_YEARLY),
        Triple("مادام‌العمر", "یک بار پرداخت", Consts.PRICE_LIFETIME),
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        Ms7LogoHeader(compact = true)
        Spacer(Modifier.height(18.dp))

        Text("ارتقا به پرمیوم", color = p.text, style = MaterialTheme.typography.headlineLarge)
        Text(
            "سرورهای اختصاصی، سرعت نامحدود و پشتیبانی ویژه دریافت کنید.",
            color = p.textDim,
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(Modifier.height(14.dp))

        // مزایا
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Benefit(Icons.Filled.Shield, "رمزنگاری\nنظام‌سطح", Modifier.weight(1f))
            Benefit(Icons.Filled.Lock, "بدون ثبت\nلاگ", Modifier.weight(1f))
            Benefit(Icons.Filled.Public, "دسترسی\nجهانی", Modifier.weight(1f))
        }

        Spacer(Modifier.height(16.dp))

        if (premiumActive) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(p.gold.copy(alpha = 0.22f), p.teal.copy(alpha = 0.12f))))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.WorkspacePremium, contentDescription = null, tint = p.gold, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("پرمیوم فعال است ✓", color = p.text, style = MaterialTheme.typography.titleMedium)
                        Text("تا تاریخ: $untilText", color = p.textDim, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        } else {
            // کارت‌های پلن
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                plans.forEachIndexed { i, (name, desc, price) ->
                    val selected = i == selectedPlan
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selected) p.teal.copy(alpha = 0.12f) else p.surface)
                            .clickable { selectedPlan = i }
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        if (i == 1) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(p.gold.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("★ محبوب", color = p.gold, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Text(name, color = p.text, style = MaterialTheme.typography.titleMedium)
                        Text(desc, color = p.textDim, style = MaterialTheme.typography.labelSmall)
                        Text(price, color = if (selected) p.teal else p.text, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // دکمه فعال‌سازی
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(p.teal, p.blue)))
                    .clickable { showCodeDialog = true; codeError = null }
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.FastForward, contentDescription = null, tint = Color(0xFF06231F), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("فعال‌سازی با کد", color = Color(0xFF06231F), style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "کد فعال‌سازی را از پشتیبانی تهیه کنید • بدون نیاز به پرداخت درون‌برنامه‌ای",
                color = p.textDim,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Spacer(Modifier.height(14.dp))

        // ویژگی‌های پایین
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(p.surface)
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            MiniFeature(Icons.Filled.FastForward, "سرعت\nبالا", Modifier.weight(1f))
            MiniFeature(Icons.Filled.Shield, "حداکثر\nحریم خصوصی", Modifier.weight(1f))
            MiniFeature(Icons.Filled.Public, "شبکه\nجهانی", Modifier.weight(1f))
            MiniFeature(Icons.Filled.WorkspacePremium, "پشتیبانی\nویژه", Modifier.weight(1f))
        }

        Spacer(Modifier.height(20.dp))
    }

    // دیالوگ کد فعال‌سازی
    if (showCodeDialog) {
        AlertDialog(
            onDismissRequest = { showCodeDialog = false },
            title = { Text("کد فعال‌سازی پرمیوم") },
            text = {
                Column {
                    Text("کد ۱۶ رقمی دریافتی از پشتیبانی را وارد کنید:", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it.uppercase().take(20); codeError = null },
                        placeholder = { Text("MS7-XXXX-XXXX-XXXX") },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            cursorColor = p.teal,
                            focusedTextColor = p.text,
                            unfocusedTextColor = p.text,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    codeError?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, color = p.danger, style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    when (val r = vm.activateCode(code)) {
                        is Activation.Result.Success -> { showCodeDialog = false; code = "" }
                        is Activation.Result.Error -> codeError = r.message
                    }
                }) { Text("فعال‌سازی") }
            },
            dismissButton = { TextButton(onClick = { showCodeDialog = false }) { Text("انصراف") } },
        )
    }
}

@Composable
private fun Benefit(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier) {
    val p = Ms7Palette
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(p.teal.copy(alpha = 0.13f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = p.text, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MiniFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier) {
    val p = Ms7Palette
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = p.blue, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(5.dp))
        Text(label, color = p.text, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
    }
}
