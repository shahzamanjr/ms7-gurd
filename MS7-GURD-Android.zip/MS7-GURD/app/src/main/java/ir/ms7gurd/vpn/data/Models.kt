package ir.ms7gurd.vpn.data

import org.json.JSONObject

/**
 * مدل‌های داده MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */

enum class Protocol(val id: String, val label: String) {
    WIREGUARD("wireguard", "WireGuard"),
    XRAY("xray", "V2Ray / Xray"),
    OPENVPN("openvpn", "OpenVPN");

    companion object {
        fun fromId(v: String) = entries.firstOrNull { it.id == v } ?: WIREGUARD
    }
}

data class Server(
    val id: String,
    val name: String,
    val city: String,
    val country: String,
    val countryCode: String,
    val protocol: Protocol,
    val premium: Boolean,
    val config: String,
    val badge: String? = null,
    var pingMs: Int? = null,
) {
    fun subtitle(): String = if (city.isBlank()) name else "$name • $city"

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("city", city)
        put("country", country)
        put("countryCode", countryCode)
        put("protocol", protocol.id)
        put("premium", premium)
        put("badge", badge ?: "")
        put("config", config)
    }

    companion object {
        fun fromJsonObject(o: JSONObject): Server = Server(
            id = o.optString("id", "srv-${System.currentTimeMillis()}"),
            name = o.optString("name", "سرور"),
            city = o.optString("city", ""),
            country = o.optString("country", ""),
            countryCode = o.optString("countryCode", "XX"),
            protocol = Protocol.fromId(o.optString("protocol", "wireguard")),
            premium = o.optBoolean("premium", false),
            config = o.optString("config", ""),
            badge = o.optString("badge", "").ifBlank { null },
        )
    }
}

/** حالت اتصال */
enum class ConnState { DISCONNECTED, CONNECTING, CONNECTED, DISCONNECTING, FAILED }

/** وضعیت کامل اتصال برای رابط کاربری */
data class ConnUiState(
    val state: ConnState = ConnState.DISCONNECTED,
    val server: Server? = null,
    val elapsedSeconds: Long = 0,
    val downMbps: Double = 0.0,
    val upMbps: Double = 0.0,
    val totalRx: Long = 0,
    val totalTx: Long = 0,
    val handshakeOk: Boolean = false,
    val message: String? = null,
)

/** حالت تونل‌بندی تفکیکی */
enum class SplitMode(val label: String) {
    NONE("غیرفعال"),
    ALLOW("فقط اپ‌های انتخابی از فیلترشکن استفاده کنند"),
    BLOCK("همه اپ‌ها از فیلترشکن استفاده کنند، به‌جز انتخابی‌ها");
}

data class SplitConfig(val mode: SplitMode = SplitMode.NONE, val apps: Set<String> = emptySet())

/** حالت تم */
enum class ThemeMode(val label: String) {
    SYSTEM("هماهنگ با سیستم"),
    DARK("تیره"),
    LIGHT("روشن");
}
