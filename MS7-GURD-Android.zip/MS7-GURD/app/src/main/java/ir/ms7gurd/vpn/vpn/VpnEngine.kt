package ir.ms7gurd.vpn.vpn

import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.SplitConfig

/**
 * قرارداد مشترک همه موتورهای VPN — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
interface VpnEngine {
    val protocol: Protocol

    /** اتصال به سرور؛ در صورت نیاز به مجوز VPN، خطای PermissionNeeded پرتاب می‌شود */
    suspend fun connect(server: Server, split: SplitConfig)

    suspend fun disconnect()

    /** بایت‌های دانلود و آپلود تجمعی (null = پشتیبانی نمی‌شود) */
    fun traffic(): Pair<Long, Long>?

    /** آخرین زمان handshake بر حسب epoch millis (0 = هنوز دست‌داده نشده) */
    fun lastHandshake(): Long

    /** آیا هسته این پروتکل در بیلد موجود است؟ */
    fun coreAvailable(): Boolean
}

/** خطاها */
class PermissionNeededException : Exception("PERMISSION")
class CoreMissingException(val coreName: String) : Exception("CORE_MISSING:$coreName")
class InvalidConfigException(override val message: String) : Exception(message)
