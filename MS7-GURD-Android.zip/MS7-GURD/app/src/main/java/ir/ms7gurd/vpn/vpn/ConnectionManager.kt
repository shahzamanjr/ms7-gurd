package ir.ms7gurd.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import ir.ms7gurd.vpn.MainActivity
import ir.ms7gurd.vpn.R
import ir.ms7gurd.vpn.core.Fa
import ir.ms7gurd.vpn.data.ConnState
import ir.ms7gurd.vpn.data.ConnUiState
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.SplitConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * مدیر اتصال — MS7 GURD (Developer: Mahdi Shahzaman)
 * هماهنگی موتورها، اعلان، تایمر، محاسبه سرعت و اتصال مجدد خودکار
 */
object ConnectionManager {

    private const val TAG = "MS7/ConnMgr"
    private const val CHANNEL_ID = "ms7_status"
    private const val NOTIF_ID = 7001
    const val ACTION_DISCONNECT = "ir.ms7gurd.vpn.ACTION_DISCONNECT"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _state = MutableStateFlow(ConnUiState())
    val state: StateFlow<ConnUiState> = _state

    private var engine: VpnEngine? = null
    private var monitorJob: Job? = null
    private var lastServer: Server? = null
    private var lastSplit = SplitConfig()
    private var connectStartMs = 0L
    private var prevRx = 0L
    private var prevTx = 0L

    // تنظیمات runtime (از ViewModel ست می‌شود)
    @Volatile var killSwitchEnabled = true
    @Volatile var notificationsEnabled = true

    private var wasConnectedBeforeLoss = false
    private var netCallbackRegistered = false

    enum class Outcome { STARTED, NEED_PERMISSION, ERROR }

    // ------------------------------------------------ connect
    suspend fun connect(context: Context, server: Server, split: SplitConfig): Outcome {
        if (_state.value.state == ConnState.CONNECTED || _state.value.state == ConnState.CONNECTING) {
            disconnect(context)
            delay(600)
        }

        lastServer = server
        lastSplit = split
        engine = engineFor(server.protocol)

        // OpenVPN: اکتیویتی کتابخانه خودش مجوز می‌گیرد
        if (server.protocol == Protocol.OPENVPN) {
            _state.value = _state.value.copy(state = ConnState.CONNECTING, server = server, message = null)
            return try {
                engine!!.connect(server, split)
                startMonitoring(server)
                Outcome.STARTED
            } catch (e: Exception) {
                failed(context, e)
                Outcome.ERROR
            }
        }

        // مجوز VPN
        val prepareIntent = android.net.VpnService.prepare(context)
        if (prepareIntent != null) {
            _state.value = _state.value.copy(state = ConnState.DISCONNECTED, server = server)
            return Outcome.NEED_PERMISSION
        }

        _state.value = _state.value.copy(state = ConnState.CONNECTING, server = server, message = "در حال اتصال…", elapsedSeconds = 0, totalRx = 0, totalTx = 0, downMbps = 0.0, upMbps = 0.0, handshakeOk = false)
        showNotification(context)

        return try {
            engine!!.connect(server, split)
            startMonitoring(server)
            Outcome.STARTED
        } catch (e: Exception) {
            failed(context, e)
            Outcome.ERROR
        }
    }

    suspend fun disconnect(context: Context) {
        monitorJob?.cancel()
        try { engine?.disconnect() } catch (e: Exception) { Log.w(TAG, "disconnect: ${e.message}") }
        _state.value = _state.value.copy(state = ConnState.DISCONNECTED, elapsedSeconds = 0, downMbps = 0.0, upMbps = 0.0, handshakeOk = false, message = null)
        cancelNotification(context)
    }

    private fun failed(context: Context, e: Exception) {
        monitorJob?.cancel()
        val msg = translateError(e)
        _state.value = _state.value.copy(state = ConnState.FAILED, message = msg)
        cancelNotification(context)
        scope.launch { delay(2500); if (_state.value.state == ConnState.FAILED) _state.value = _state.value.copy(state = ConnState.DISCONNECTED) }
    }

    private fun translateError(e: Exception): String = when {
        e is PermissionNeededException -> "مجوز VPN داده نشد"
        e is CoreMissingException -> "${e.coreName} نصب نشده است — راهنمای بخش «درباره» را ببینید"
        e is InvalidConfigException -> e.message ?: "کانفیگ نامعتبر است"
        else -> "اتصال ناموفق بود: ${e.message ?: "خطای ناشناخته"}"
    }

    private fun engineFor(p: Protocol): VpnEngine = when (p) {
        Protocol.WIREGUARD -> WireGuardEngine
        Protocol.XRAY -> XrayEngine
        Protocol.OPENVPN -> OpenVpnEngine
    }

    // ------------------------------------------------ monitoring
    private fun startMonitoring(server: Server) {
        connectStartMs = System.currentTimeMillis()
        prevRx = 0; prevTx = 0
        registerNetworkCallback()

        _state.value = _state.value.copy(state = ConnState.CONNECTED, server = server, message = null)
        showNotification(contextOfApp)

        var handshakeWarned = false
        monitorJob?.cancel()
        monitorJob = scope.launch(Dispatchers.Default) {
            while (_state.value.state == ConnState.CONNECTED) {
                delay(1000)
                val eng = engine ?: break
                val tr = eng.traffic()
                val elapsed = (System.currentTimeMillis() - connectStartMs) / 1000

                var downMbps = 0.0; var upMbps = 0.0
                if (tr != null) {
                    val rx = tr.first; val tx = tr.second
                    if (prevRx > 0 && rx >= prevRx) downMbps = ((rx - prevRx) * 8.0) / 1_000_000.0
                    if (prevTx > 0 && tx >= prevTx) upMbps = ((tx - prevTx) * 8.0) / 1_000_000.0
                    prevRx = rx; prevTx = tx
                    _state.value = _state.value.copy(elapsedSeconds = elapsed, downMbps = downMbps, upMbps = upMbps, totalRx = rx, totalTx = tx)
                } else {
                    _state.value = _state.value.copy(elapsedSeconds = elapsed)
                }

                // وضعیت handshake (فقط WireGuard)
                if (eng.protocol == Protocol.WIREGUARD) {
                    val hs = eng.lastHandshake()
                    val ok = hs > 0
                    _state.value = _state.value.copy(handshakeOk = ok)
                    if (!ok && elapsed > 30 && !handshakeWarned) {
                        handshakeWarned = true
                        _state.value = _state.value.copy(message = "دست‌دادن با سرور انجام نشد — کلیدها و آدرس سرور را بررسی کنید")
                    }
                    if (ok) showNotification(contextOfApp) // یک بار وضعیت امن نمایش داده شود
                }
            }
        }
    }

    // ------------------------------------------------ callbacks
    fun onVpnRevoked() {
        Log.i(TAG, "VPN revoked by system")
        monitorJob?.cancel()
        scope.launch {
            _state.value = _state.value.copy(state = ConnState.DISCONNECTED, handshakeOk = false)
            cancelNotification(contextOfApp)
        }
    }

    fun onEngineFatal(msg: String) {
        monitorJob?.cancel()
        scope.launch {
            _state.value = _state.value.copy(state = ConnState.FAILED, message = "خطای هسته: $msg")
            cancelNotification(contextOfApp)
        }
    }

    // اتصال مجدد خودکار وقتی اینترنت برمی‌گردد (کیل‌سوئیچ)
    private fun registerNetworkCallback() {
        if (netCallbackRegistered) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return // registerDefaultNetworkCallback از API ۲۴
        try {
            val cm = contextOfApp.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (!killSwitchEnabled) return
                    if (!wasConnectedBeforeLoss) return
                    if (_state.value.state == ConnState.CONNECTED || _state.value.state == ConnState.CONNECTING) return
                    val server = lastServer ?: return
                    wasConnectedBeforeLoss = false
                    scope.launch {
                        delay(1500)
                        _state.value = _state.value.copy(state = ConnState.CONNECTING, message = "اتصال مجدد…")
                        runCatching { engineFor(server.protocol).connect(server, lastSplit) }
                        if (_state.value.state == ConnState.CONNECTING) startMonitoring(server)
                    }
                }

                override fun onLost(network: Network) {
                    if (killSwitchEnabled && _state.value.state == ConnState.CONNECTED) wasConnectedBeforeLoss = true
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCallbackRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "netcallback: ${e.message}")
        }
    }

    // اتصال خودکار هنگام باز شدن اپ
    suspend fun autoConnectIfNeeded(context: Context, server: Server, split: SplitConfig) {
        if (_state.value.state != ConnState.DISCONNECTED) return
        connect(context, server, split)
    }

    // ------------------------------------------------ notification
    private lateinit var contextOfApp: Context

    fun init(context: Context) {
        contextOfApp = context.applicationContext
        val nm = contextOfApp.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, contextOfApp.getString(R.string.notification_channel_status), NotificationManager.IMPORTANCE_LOW).apply {
                    description = contextOfApp.getString(R.string.notification_channel_status_desc)
                }
            )
        }
    }

    private fun buildNotification(context: Context, s: ConnUiState): Notification {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getBroadcast(
            context, 1, Intent(context, Ms7NotifyReceiver::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title: String
        val text: String
        when (s.state) {
            ConnState.CONNECTING -> { title = "در حال اتصال…"; text = "MS7 GURD — لطفاً صبر کنید" }
            ConnState.CONNECTED -> {
                title = "متصل — " + (s.server?.name ?: "سرور")
                text = if (s.handshakeOk || s.server?.protocol != Protocol.WIREGUARD) "اتصال شما امن است • ${Fa.timer(s.elapsedSeconds)}" else "در حال دست‌دادن…"
            }
            else -> { title = "قطع شده"; text = "MS7 GURD" }
        }
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_ms7)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .apply { if (s.state == ConnState.CONNECTED || s.state == ConnState.CONNECTING) addAction(0, "قطع اتصال", stopIntent) }
            .build()
    }

    private fun showNotification(context: Context) {
        if (!notificationsEnabled) return
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(context, _state.value))
        } catch (e: Exception) { Log.w(TAG, "notif: ${e.message}") }
    }

    fun refreshNotification() = showNotification(contextOfApp)

    private fun cancelNotification(context: Context) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIF_ID)
        } catch (e: Exception) {}
    }
}

/** گیرنده اکشن «قطع اتصال» در اعلان */
class Ms7NotifyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ConnectionManager.ACTION_DISCONNECT) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                ConnectionManager.disconnect(context.applicationContext)
            }
        }
    }
}
