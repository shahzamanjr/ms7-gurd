package ir.ms7gurd.vpn.core

/**
 * تنظیمات قابل ویرایش برند MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 *
 * ⚠️ قبل از انتشار، لینک‌های پشتیبانی را با لینک‌های واقعی خودتان جایگزین کنید.
 */
object Consts {
    const val APP_NAME = "MS7 GURD"
    const val TAGLINE = "امن. خصوصی. بی‌نهایت."
    const val DEVELOPER = "مهدی شاه‌زمان"
    const val VERSION = "1.0.0"

    // لینک‌های پشتیبانی — این‌ها را عوض کنید
    const val SUPPORT_TELEGRAM = "https://t.me/MS7GURD"
    const val SUPPORT_EMAIL = "support@ms7gurd.ir"
    const val SUPPORT_WEBSITE = "https://ms7gurd.ir"
    const val PRIVACY_URL = "https://ms7gurd.ir/privacy"

    // پلن‌های پرمیوم (تومان) — قیمت‌ها را اینجا عوض کنید
    const val PRICE_MONTHLY = "۹۹٫۰۰۰ تومان"
    const val PRICE_YEARLY = "۷۹۰٫۰۰۰ تومان"
    const val PRICE_LIFETIME = "۱٫۹۹۰٫۰۰۰ تومان"
    const val PRICE_YEARLY_NOTE = "معادل ۶۵٫۰۰۰ تومان در ماه"
}
