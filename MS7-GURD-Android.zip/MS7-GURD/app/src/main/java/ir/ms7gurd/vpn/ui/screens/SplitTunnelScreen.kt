package ir.ms7gurd.vpn.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.data.SplitMode
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * تونل‌بندی تفکیکی — انتخاب اپ‌ها — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */

data class AppEntry(val packageName: String, val label: String, val iconBitmap: androidx.compose.ui.graphics.ImageBitmap)

@Composable
fun SplitTunnelScreen(vm: MainViewModel, onBack: () -> Unit) {
    val p = Ms7Palette
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()

    // لیست اپ‌های نصب‌شده (هر بار ورود به صفحه)
    val apps = rememberApps(context)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.surface)
                    .clickable(onClick = onBack)
                    .padding(8.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = p.text, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("تونل‌بندی تفکیکی", color = p.text, style = MaterialTheme.typography.headlineSmall)
                Text("کنترل اینکه کدام اپ‌ها از فیلترشکن استفاده کنند", color = p.textDim, style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(Modifier.height(14.dp))

        // حالت‌ها
        SplitMode.entries.forEach { mode ->
            val selected = settings.splitMode == mode
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(if (selected) p.teal.copy(alpha = 0.12f) else p.surface)
                    .clickable { vm.setSplitMode(mode) }
                    .padding(horizontal = 13.dp, vertical = 11.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(18.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(if (selected) p.teal else p.outline)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(mode.label, color = p.text, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (settings.splitMode == SplitMode.NONE) {
            Text(
                "برای انتخاب اپ‌ها، اول یک حالت بالا را انتخاب کنید",
                color = p.textDim,
                style = MaterialTheme.typography.labelMedium,
            )
        } else {
            Text(
                if (settings.splitMode == SplitMode.ALLOW) "اپ‌هایی که از فیلترشکن استفاده می‌کنند:"
                else "اپ‌هایی که از فیلترشکن استفاده نمی‌کنند:",
                color = p.textDim,
                style = MaterialTheme.typography.labelMedium,
            )
            Spacer(Modifier.height(8.dp))

            LazyColumn {
                items(apps, key = { it.packageName }) { app ->
                    val checked = app.packageName in settings.splitApps
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(if (checked) p.teal.copy(alpha = 0.09f) else p.surface)
                            .clickable {
                                val newSet = if (checked) settings.splitApps - app.packageName else settings.splitApps + app.packageName
                                vm.setSplitApps(newSet)
                            }
                            .padding(horizontal = 11.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(app.iconBitmap, contentDescription = null, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(app.label, color = p.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Box(
                            Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (checked) p.teal else p.outline),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (checked) {
                                Text("✓", color = androidx.compose.ui.graphics.Color(0xFF06231F), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun rememberApps(context: android.content.Context): List<AppEntry> {
    return androidx.compose.runtime.remember {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ris = pm.queryIntentActivities(intent, 0)
        ris.mapNotNull { ri ->
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = try { ri.loadLabel(pm)?.toString() ?: pkg } catch (e: Exception) { pkg }
            val icon = try { drawableToBitmap(ri.loadIcon(pm)) } catch (e: Exception) { null } ?: return@mapNotNull null
            AppEntry(pkg, label, icon.asImageBitmap())
        }.sortedBy { it.label.lowercase() }
    }
}

private fun drawableToBitmap(drawable: Drawable): Bitmap {
    val size = 96
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    drawable.setBounds(0, 0, size, size)
    drawable.draw(canvas)
    return bmp
}
