package ir.ms7gurd.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.data.ConfigImporter
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.components.Ms7Card
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * صفحه افزودن کانفیگ — متن / بارکد QR / سابسکریپشن
 * MS7 GURD (Developer: Mahdi Shahzaman)
 */
@Composable
fun AddConfigScreen(vm: MainViewModel, onBack: () -> Unit) {
    val p = Ms7Palette
    var tab by remember { mutableStateOf(0) } // 0=متن 1=QR 2=ساب

    Column(
        Modifier
            .fillMaxSize()
            .background(p.bg)
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.surface)
                    .clickable(onClick = onBack)
                    .padding(8.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = p.text, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text("افزودن کانفیگ", color = p.text, style = MaterialTheme.typography.headlineSmall)
        }

        Spacer(Modifier.height(16.dp))

        // تب‌ها
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(p.surface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            listOf(
                Triple("متن کانفیگ", Icons.Filled.ContentPaste, 0),
                Triple("بارکد QR", Icons.Filled.QrCodeScanner, 1),
                Triple("سابسکریپشن", Icons.Filled.Link, 2),
            ).forEach { (label, icon, idx) ->
                val selected = tab == idx
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(11.dp))
                        .background(if (selected) p.teal.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable { tab = idx }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, contentDescription = null, tint = if (selected) p.teal else p.textDim, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(label, color = if (selected) p.teal else p.textDim, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        when (tab) {
            0 -> PasteTab(vm)
            1 -> QrTab(vm)
            2 -> SubscriptionTab(vm)
        }
    }
}

// ------------------------------------------------ تب ۱: متن
@Composable
private fun PasteTab(vm: MainViewModel) {
    val p = Ms7Palette
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Ms7Card {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = {
                    Text(
                        "کانفیگ را اینجا بچسبانید…\n\nپشتیبانی از: WireGuard، VLESS، VMess، Trojan، Shadowsocks و OpenVPN",
                        color = p.textDim.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                },
                minLines = 6,
                maxLines = 12,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    cursorColor = p.teal,
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionButton(
                text = "چسباندن",
                tint = p.blue,
                modifier = Modifier.weight(1f),
            ) {
                val clip = clipboard.getText()?.text
                if (!clip.isNullOrBlank()) text = clip
            }
            ActionButton(
                text = "ذخیره کانفیگ",
                tint = p.teal,
                enabled = text.isNotBlank(),
                modifier = Modifier.weight(2f),
            ) {
                try {
                    val (type, servers) = ConfigImporter.parseMany(text)
                    vm.addServers(servers)
                    text = ""
                } catch (e: Exception) {
                    vm.snackbar.value = "کانفیگ قابل تشخیص نیست — متن را کامل کپی کنید"
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = p.textDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "نوع کانفیگ به‌صورت خودکار تشخیص داده می‌شود",
                color = p.textDim,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

// ------------------------------------------------ تب ۲: QR
@Composable
private fun QrTab(vm: MainViewModel) {
    QrScannerView { result ->
        if (result != null) {
            try {
                val (_, servers) = ConfigImporter.parseMany(result)
                vm.addServers(servers)
                vm.snackbar.value = "کانفیگ از QR اضافه شد"
            } catch (e: Exception) {
                vm.snackbar.value = "محتوای QR قابل تشخیص نیست"
            }
        }
    }
}

// ------------------------------------------------ تب ۳: سابسکریپشن
@Composable
private fun SubscriptionTab(vm: MainViewModel) {
    val p = Ms7Palette
    var url by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Ms7Card {
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                placeholder = { Text("https://panel.example.com/sub/xxxx", color = p.textDim.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    cursorColor = p.teal,
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Spacer(Modifier.height(10.dp))

        ActionButton(
            text = if (loading) "در حال دریافت…" else "دریافت و افزودن سرورها",
            tint = p.teal,
            enabled = url.isNotBlank() && !loading,
        ) {
            loading = true
            vm.fetchSubscription(url)
            loading = false
        }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = p.textDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("لینک سابسکریپشن پنل (مارزبان و…): همه کانفیگ‌ها یک‌جا اضافه می‌شوند", color = p.textDim, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ActionButton(text: String, tint: androidx.compose.ui.graphics.Color, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = Ms7Palette
    Box(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(if (enabled) tint.copy(alpha = 0.16f) else p.textDim.copy(alpha = 0.08f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (enabled) tint else p.textDim, style = MaterialTheme.typography.labelLarge)
    }
}
