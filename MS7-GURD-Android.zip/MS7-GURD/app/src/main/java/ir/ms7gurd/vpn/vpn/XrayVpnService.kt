package ir.ms7gurd.vpn.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import ir.ms7gurd.vpn.R
import ir.ms7gurd.vpn.data.SplitConfig
import ir.ms7gurd.vpn.data.SplitMode
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

/**
 * سرویس VPN هسته Xray — MS7 GURD (Developer: Mahdi Shahzaman)
 * ساخت TUN و تحویل fd به هسته libv2ray (الگوی v2rayNG)
 */
class XrayVpnService : android.net.VpnService() {

    companion object {
        const val TAG = "MS7/XrayVpn"
        @Volatile
        private var fdFuture = CompletableFuture<Long>()
        @Volatile
        var activeInstance: XrayVpnService? = null
            private set

        /** منتظر آماده شدن fd می‌ماند (۵ ثانیه) */
        fun awaitFd(): Long = try {
            fdFuture.get(5, TimeUnit.SECONDS)
        } catch (e: Exception) {
            -1L
        }

        /** قبل از هر اتصال جدید باید صدا زده شود */
        fun resetFd() {
            fdFuture = CompletableFuture()
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var split: SplitConfig = SplitConfig()

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        split = XrayEngine.pendingSplit ?: SplitConfig()
        establishTun()
        startForegroundCompat()
        return START_STICKY
    }

    /** سرویس پیش‌زمینه — ضروری برای پایداری تونل روی اندروید ۱۲ به بعد */
    private fun startForegroundCompat() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel("ms7_status") == null) {
                nm.createNotificationChannel(
                    NotificationChannel("ms7_status", "وضعیت اتصال", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val notif = NotificationCompat.Builder(this, "ms7_status")
                .setSmallIcon(R.drawable.ic_stat_ms7)
                .setContentTitle("MS7 GURD")
                .setContentText("تونل Xray فعال است")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
            startForeground(7002, notif)
        } catch (e: Exception) {
            Log.w(TAG, "startForeground: ${e.message}")
        }
    }

    private fun establishTun() {
        try {
            if (tun != null) return
            val builder = Builder()
                .setSession("MS7_GURD")
                .setMtu(8500)
                .addAddress("26.26.26.1", 32)
                .addDnsServer("26.26.26.2")
                .addRoute("0.0.0.0", 0)

            when (split.mode) {
                SplitMode.BLOCK -> split.apps.forEach { runCatching { builder.addDisallowedApplication(it) } }
                SplitMode.ALLOW -> split.apps.forEach { runCatching { builder.addAllowedApplication(it) } }
                else -> {}
            }

            tun = builder.establish()
            val fd = tun?.detachFd() ?: -1
            Log.i(TAG, "TUN established, fd=$fd")
            if (fd > 0) fdFuture.complete(fd.toLong()) else fdFuture.complete(-1L)
        } catch (e: Exception) {
            Log.e(TAG, "establish failed", e)
            fdFuture.complete(-1L)
        }
    }

    override fun onRevoke() {
        XrayEngine.onServiceRevoked()
        stopSelf()
    }

    override fun onDestroy() {
        activeInstance = null
        try { tun?.close() } catch (e: Exception) {}
        tun = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder = super.onBind(intent) ?: Binder()
}
