package ir.ms7gurd.vpn.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray

private val Context.serversDataStore by preferencesDataStore(name = "ms7_servers")

/**
 * مخزن سرورها — MS7 GURD (Developer: Mahdi Shahzaman)
 * بار اول: لیست پیش‌فرض از assets/servers_default.json
 */
class ServerStore(private val context: Context) {

    private val key = stringPreferencesKey("servers_json")

    val servers: Flow<List<Server>> = context.serversDataStore.data.map { p ->
        parseServers(p[key] ?: defaultJson())
    }

    suspend fun replaceAll(list: List<Server>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJsonObject()) }
        context.serversDataStore.edit { it[key] = arr.toString() }
    }

    suspend fun addAll(list: List<Server>) = replaceAll(servers.first() + list)

    suspend fun delete(id: String) = replaceAll(servers.first().filterNot { it.id == id })

    suspend fun clearAll() = replaceAll(emptyList())

    private fun parseServers(json: String): List<Server> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { Server.fromJsonObject(arr.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun defaultJson(): String = try {
        context.assets.open("servers_default.json").bufferedReader().use { it.readText() }
            .let { full ->
                val root = org.json.JSONObject(full)
                root.getJSONArray("servers").toString()
            }
    } catch (e: Exception) {
        "[]"
    }
}
