package ir.ms7gurd.vpn

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.ms7gurd.vpn.data.ThemeMode
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.nav.Ms7App
import ir.ms7gurd.vpn.ui.theme.Ms7Theme

/**
 * اکتیویتی اصلی — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
class MainActivity : ComponentActivity() {

    private var requested = false

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            requested = granted
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        splash.setKeepOnScreenCondition { false }

        // مجوز اعلان (اندروید ۱۳+) — یک بار
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            Ms7Theme(mode = settings.themeMode) {
                Ms7App(vm = vm)
            }
        }
    }
}
