package ir.ms7gurd.vpn.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.core.Consts
import ir.ms7gurd.vpn.ui.components.Ms7Card
import ir.ms7gurd.vpn.ui.components.Ms7LogoHeader
import ir.ms7gurd.vpn.ui.components.SectionTitle
import ir.ms7gurd.vpn.ui.theme.Ms7Palette

/**
 * صفحه پشتیبانی — MS7 GURD (Developer: Mahdi Shahzaman)
 */
@Composable
fun SupportScreen(vm: ir.ms7gurd.vpn.ui.MainViewModel) {
    val p = Ms7Palette
    val context = LocalContext.current

    fun open(url: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            vm.snackbar.value = "برنامه مناسبی برای باز کردن لینک پیدا نشد"
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Ms7LogoHeader()
        Spacer(Modifier.height(6.dp))
        Text(
            "هر سوالی دارید، ما پاسخ می‌دهیم",
            color = p.textDim,
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(Modifier.height(16.dp))

        SectionTitle("تماس با پشتیبانی")
        Spacer(Modifier.height(8.dp))
        Ms7Card {
            ContactRow(Icons.Filled.Send, "تلگرام پشتیبانی", Consts.SUPPORT_TELEGRAM.removePrefix("https://")) {
                open(Consts.SUPPORT_TELEGRAM)
            }
            MiniDivider()
            ContactRow(Icons.Filled.Email, "ایمیل", Consts.SUPPORT_EMAIL) {
                open("mailto:${Consts.SUPPORT_EMAIL}")
            }
            MiniDivider()
            ContactRow(Icons.Filled.Language, "وبسایت", Consts.SUPPORT_WEBSITE.removePrefix("https://")) {
                open(Consts.SUPPORT_WEBSITE)
            }
        }

        Spacer(Modifier.height(16.dp))

        SectionTitle("راهنمای سریع")
        Spacer(Modifier.height(8.dp))
        Ms7Card {
            FaqItem(
                q = "چطور وصل شوم؟",
                a = "از تب «سرورها» یک سرور انتخاب کنید یا کانفیگ خود را اضافه کنید، بعد دکمه بزرگ وسط صفحه خانه را بزنید. بار اول اندروید مجوز VPN می‌پرسد — تأیید کنید.",
            )
            MiniDivider()
            FaqItem(
                q = "کانفیگ دارم، از کجا اضافه کنم؟",
                a = "در تب «سرورها» دکمه «افزودن کانفیگ» را بزنید. می‌توانید متن کانفیگ را بچسبانید، QR اسکن کنید یا لینک سابسکریپشن پنل را وارد کنید. WireGuard، VLESS، VMess، Trojan، Shadowsocks و OpenVPN پشتیبانی می‌شوند.",
            )
            MiniDivider()
            FaqItem(
                q = "سرعت کم است، چه کنم؟",
                a = "با دکمه «تست پینگ» در صفحه سرورها، سریع‌ترین سرور را پیدا کنید. همچنین MTU کانفیگ WireGuard را می‌توانید به ۱۳۶۰ کاهش دهید.",
            )
            MiniDivider()
            FaqItem(
                q = "کیل‌سوئیچ چیست؟",
                a = "اگر اتصال VPN ناگهان قطع شود، کیل‌سوئیچ جلوی ارسال اینترنت بدون رمزنگاری را می‌گیرد تا آی‌پی شما لو نرود. از تنظیمات قابل فعال‌سازی است.",
            )
        }

        Spacer(Modifier.height(16.dp))

        // اشتراک‌گذاری اپ
        Ms7Card {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "MS7 GURD — فیلترشکن سریع و امن\n${Consts.SUPPORT_WEBSITE}")
                        }
                        context.startActivity(Intent.createChooser(send, "اشتراک‌گذاری MS7 GURD"))
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Share, contentDescription = null, tint = p.blue, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(11.dp))
                Text("اشتراک‌گذاری MS7 GURD", color = p.text, style = MaterialTheme.typography.titleSmall)
            }
        }

        Spacer(Modifier.height(22.dp))

        // --- امضای توسعه‌دهنده ---
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(p.teal.copy(alpha = 0.10f), p.blue.copy(alpha = 0.08f))
                    )
                )
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null, tint = p.teal, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(8.dp))
            Text("توسعه‌دهنده", color = p.textDim, style = MaterialTheme.typography.labelMedium)
            Text(
                Consts.DEVELOPER,
                color = p.text,
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "نسخه ${Consts.VERSION} • ${Consts.APP_NAME}",
                color = p.textDim,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
            )
        }

        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun ContactRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val p = Ms7Palette
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(p.teal.copy(alpha = 0.11f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
            Text(sub, color = p.textDim, style = MaterialTheme.typography.labelSmall)
        }
        Text("باز کردن", color = p.teal, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun FaqItem(q: String, a: String) {
    val p = Ms7Palette
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Shield, contentDescription = null, tint = p.blue, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text(q, color = p.text, style = MaterialTheme.typography.titleSmall)
        }
        Spacer(Modifier.height(4.dp))
        Text(a, color = p.textDim, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MiniDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .height(1.dp)
            .background(Ms7Palette.outline.copy(alpha = 0.4f))
    )
}
