package ir.ms7gurd.vpn.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * پالت رنگ MS7 GURD — Developer: Mahdi Shahzaman
 */

// ---- تیره (پیش‌فرض برند)
val DarkBg = Color(0xFF0A1628)
val DarkBgSoft = Color(0xFF0D1D33)
val DarkSurface = Color(0xFF0F2240)
val DarkSurfaceHigh = Color(0xFF142B4C)
val DarkOutline = Color(0xFF1E3A5F)
val DarkText = Color(0xFFF2F7FA)
val DarkTextDim = Color(0xFF8FA5BD)
val DarkAccentTeal = Color(0xFF2DD4BF)
val DarkAccentBlue = Color(0xFF3B82F6)
val DarkGold = Color(0xFFF5B942)
val DarkDanger = Color(0xFFF87171)

// ---- روشن
val LightBg = Color(0xFFF1F5FA)
val LightBgSoft = Color(0xFFE8EFF7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFF3F7FC)
val LightOutline = Color(0xFFD5E0EC)
val LightText = Color(0xFF0F2440)
val LightTextDim = Color(0xFF5B7089)
val LightAccentTeal = Color(0xFF0E9384)
val LightAccentBlue = Color(0xFF2563EB)
val LightGold = Color(0xFFB7791F)
val LightDanger = Color(0xFFDC2626)

/** گرادیان برند آبی→فیروزه‌ای */
val BrandBrush = Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF2DD4BF)))
