package ir.ms7gurd.vpn.vpn

import android.content.Context
import android.content.Intent
import ir.ms7gurd.vpn.data.ConfigImporter
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.SplitConfig
import java.io.File
import java.lang.reflect.InvocationHandler
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/**
 * موتور Xray (VLESS / VMess / Trojan / Shadowsocks / Reality) — MS7 GURD
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 *
 * اتصال با Reflection به هسته رسمی libv2ray (AndroidLibXrayLite نسخه ۲۰۲۵ به بعد، API
 * «CoreController» — همان الگوی v2rayNG):
 *   Libv2ray.initCoreEnv(assetDir, key)
 *   Libv2ray.newCoreController(CoreCallbackHandler)
 *   controller.startLoop(configJson, tunFd)   ← هسته خودش TUN و محافظت سوکت را انجام می‌دهد
 *   controller.stopLoop()
 *   controller.queryAllOutboundTrafficStats()
 *
 * برای فعال‌سازی: فایل libv2ray.aar را در پوشه app/libs بگذارید (README-FA.md بخش ۲).
 * بدون AAR، بیلد کامپایل می‌شود و کاربر خطای «هسته نصب نشده» می‌بیند.
 */
object XrayEngine : VpnEngine {

    override val protocol = Protocol.XRAY

    @Volatile var pendingSplit: SplitConfig? = null
        private set

    private var controller: Any? = null
    private var stopping = false
    private var lastRx = 0L
    private var lastTx = 0L
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    override fun coreAvailable(): Boolean = try {
        Class.forName("libv2ray.Libv2ray") != null
    } catch (e: Throwable) {
        false
    }

    // ---------- connection ----------
    override suspend fun connect(server: Server, split: SplitConfig) {
        val ctx = appContext ?: throw InvalidConfigException("زمینه برنامه آماده نیست")
        if (!coreAvailable()) throw CoreMissingException("هسته Xray (libv2ray.aar)")

        val json = try {
            ConfigImporter.buildXrayJson(server.config)
        } catch (e: Exception) {
            throw InvalidConfigException("کانفیگ Xray نامعتبر است: ${e.message ?: ""}")
        }

        ensureAssets(ctx)

        // ۱) سرویس VPN → ساخت TUN و گرفتن fd
        pendingSplit = split
        XrayVpnService.resetFd()
        try {
            ctx.startService(Intent(ctx, XrayVpnService::class.java))
        } catch (e: Exception) {
            throw InvalidConfigException("سرویس VPN شروع نشد — اپ را از داخل خودش اجرا کنید")
        }
        val fd = XrayVpnService.awaitFd()
        if (fd <= 0) throw InvalidConfigException("تونل VPN ساخته نشد — مجوز VPN را بررسی کنید")

        // ۲) راه‌اندازی هسته از طریق Reflection (API جدید CoreController)
        try {
            val lib = Class.forName("libv2ray.Libv2ray")

            // Libv2ray.initCoreEnv(assetDir, key) — مسیر asset ها (geoip.dat و…)
            lib.methods.firstOrNull { it.name.equals("initCoreEnv", true) }
                ?.invoke(null, assetsDir(ctx), "")

            // CoreCallbackHandler → Proxy
            val cbInterface = Class.forName("libv2ray.CoreCallbackHandler")
            val handler = Proxy.newProxyInstance(
                cbInterface.classLoader, arrayOf(cbInterface),
                InvocationHandler { _, method, _ -> handleCallback(method) }
            )

            // controller = Libv2ray.newCoreController(handler)
            val newCtl = lib.methods.first { it.name.equals("newCoreController", true) }
            val ctl = newCtl.invoke(null, handler)

            // controller.startLoop(configJson, tunFd)
            val start = ctl.javaClass.methods.first { it.name.equals("startLoop", true) }
            stopping = false
            lastRx = 0; lastTx = 0
            start.invoke(ctl, json, fd.toInt())

            controller = ctl
        } catch (e: InvocationTargetException) {
            controller = null
            XrayVpnService.activeInstance?.stopSelf()
            val cause = e.cause?.message ?: e.message ?: ""
            throw InvalidConfigException("خطای هسته Xray: $cause")
        } catch (e: Exception) {
            controller = null
            XrayVpnService.activeInstance?.stopSelf()
            throw InvalidConfigException("نسخه هسته Xray سازگار نیست (${e.javaClass.simpleName}) — از AndroidLibXrayLite نسخه ۲۰۲۵ به بعد استفاده کنید")
        }
    }

    override suspend fun disconnect() {
        stopping = true
        val ctl = controller
        if (ctl != null) {
            try {
                ctl.javaClass.methods.firstOrNull { it.name.equals("stopLoop", true) }?.invoke(ctl)
            } catch (e: Exception) {}
        }
        controller = null
        appContext?.stopService(Intent(appContext, XrayVpnService::class.java))
    }

    fun onServiceRevoked() {
        stopping = true
        val ctl = controller
        if (ctl != null) {
            try {
                ctl.javaClass.methods.firstOrNull { it.name.equals("stopLoop", true) }?.invoke(ctl)
            } catch (e: Exception) {}
        }
        controller = null
        ConnectionManager.onVpnRevoked()
    }

    override fun traffic(): Pair<Long, Long>? {
        val ctl = controller ?: return null
        return try {
            val m = ctl.javaClass.methods.firstOrNull { it.name.equals("queryAllOutboundTrafficStats", true) }
                ?: return null
            val text = (m.invoke(ctl) as? String) ?: return null
            // قالب: "tag,direction,value;tag,direction,value;" — هر بار مقادیر «از آخرین پرسش» است
            var rx = 0L; var tx = 0L
            text.split(";").forEach { entry ->
                val parts = entry.trim().split(",")
                if (parts.size == 3) {
                    val dir = parts[1].lowercase()
                    val value = parts[2].toLongOrNull() ?: 0L
                    when (dir) {
                        "downlink" -> rx += value
                        "uplink" -> tx += value
                    }
                }
            }
            lastRx += rx
            lastTx += tx
            lastRx to lastTx
        } catch (e: Exception) {
            null
        }
    }

    override fun lastHandshake(): Long = try {
        val ctl = controller ?: return 0
        val m = ctl.javaClass.methods.firstOrNull { it.name.equals("getIsRunning", true) } ?: return if (controller != null) 1 else 0
        if (m.invoke(ctl) as? Boolean == true) 1L else 0L
    } catch (e: Exception) {
        if (controller != null) 1L else 0L
    }

    // ---------- callbacks از هسته ----------
    private fun handleCallback(method: Method): Any = when (method.name.lowercase()) {
        "startup" -> 0L
        "shutdown" -> {
            // اگر هسته خودش خاموش شد (نه با درخواست ما) → اطلاع به مدیر اتصال
            if (!stopping) {
                controller = null
                ConnectionManager.onEngineFatal("هسته Xray متوقف شد")
            }
            0L
        }
        "onemitstatus" -> 0L
        else -> 0L
    }

    // ---------- assets ----------
    private fun assetsDir(ctx: Context): String {
        val dir = File(ctx.filesDir, "xray_assets")
        if (!dir.exists()) dir.mkdirs()
        return dir.absolutePath
    }

    private fun ensureAssets(ctx: Context) {
        // فایل‌های geo (اختیاری): اگر داخل APK (مثلاً همراه AAR) باشند، در filesDir کپی می‌شوند؛
        // در غیر این صورت هسته خودش مستقیماً از asset های APK می‌خواند.
        val dir = assetsDir(ctx)
        listOf("geoip.dat", "geosite.dat", "geoip-only-cn-private.dat").forEach { name ->
            val target = File(dir, name)
            if (!target.exists()) {
                listOf(name, "xray/$name").forEach { assetPath ->
                    if (!target.exists()) {
                        try {
                            ctx.assets.open(assetPath).use { input ->
                                target.outputStream().use { input.copyTo(it) }
                            }
                        } catch (e: Exception) { /* اختیاری است */ }
                    }
                }
            }
        }
    }
}
