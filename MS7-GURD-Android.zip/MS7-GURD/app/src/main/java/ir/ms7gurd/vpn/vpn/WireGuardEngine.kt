package ir.ms7gurd.vpn.vpn

import android.content.Context
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Statistics
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import ir.ms7gurd.vpn.data.Protocol
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.SplitConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

/**
 * موتور WireGuard — کاملاً فعال با کتابخانه رسمی
 * Developer: Mahdi Shahzaman (مهدی شاه‌زمان)
 */
object WireGuardEngine : VpnEngine {

    override val protocol = Protocol.WIREGUARD

    private var backend: GoBackend? = null
    private var tunnel: WgTunnel? = null
    private var lastStats: Statistics? = null

    private class WgTunnel(private val name: String) : Tunnel {
        override fun getName(): String = name
        override fun onStateChange(newState: Tunnel.State) {}
    }

    /** آماده‌سازی هسته (بهتر است در نخ پس‌زمینه صدا زده شود؛ بارگذاری کتابخانه زمان‌بر است) */
    fun warmUp(appContext: Context) {
        try {
            if (backend == null) backend = GoBackend(appContext)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    override fun coreAvailable(): Boolean = try {
        backend != null
    } catch (e: Throwable) {
        false
    }

    override suspend fun connect(server: Server, split: SplitConfig) = withContext(Dispatchers.IO) {
        val b = backend ?: throw InvalidConfigException("هسته WireGuard هنوز آماده نشده است")

        val text = applySplit(server.config, split)
        val cfg = try {
            Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
        } catch (e: Exception) {
            throw InvalidConfigException("کانفیگ WireGuard نامعتبر است: ${e.message ?: ""}")
        }

        val t = WgTunnel("ms7_${server.id.take(24)}")
        try {
            b.setState(t, Tunnel.State.UP, cfg)
        } catch (e: BackendException) {
            throw translate(e)
        } catch (e: Exception) {
            throw InvalidConfigException("اتصال برقرار نشد: ${e.message ?: "خطای ناشناخته"}")
        }
        tunnel = t
        lastStats = null
    }

    override suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            tunnel?.let { backend?.setState(it, Tunnel.State.DOWN, null) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        tunnel = null
    }

    override fun traffic(): Pair<Long, Long>? {
        val t = tunnel ?: return null
        val b = backend ?: return null
        return try {
            val st = b.getStatistics(t)
            lastStats = st
            st.totalRx() to st.totalTx()
        } catch (e: Exception) {
            null
        }
    }

    override fun lastHandshake(): Long {
        val t = tunnel ?: return 0
        val b = backend ?: return 0
        return try {
            val s = b.getStatistics(t)
            lastStats = s
            val key = s.peers().firstOrNull() ?: return 0
            s.peer(key)?.latestHandshakeEpochMillis() ?: 0L
        } catch (e: Exception) {
            0
        }
    }

    // ---------- helpers ----------
    private fun applySplit(text: String, split: SplitConfig): String {
        if (split.mode == ir.ms7gurd.vpn.data.SplitMode.NONE || split.apps.isEmpty()) return text
        val apps = split.apps.joinToString(", ")
        val line = when (split.mode) {
            ir.ms7gurd.vpn.data.SplitMode.BLOCK -> "ExcludedApplications = $apps"
            ir.ms7gurd.vpn.data.SplitMode.ALLOW -> "IncludedApplications = $apps"
            else -> return text
        }
        val lines = text.lines().toMutableList()
        val idx = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
        return if (idx >= 0) {
            lines.add(idx + 1, line)
            lines.joinToString("\n")
        } else text
    }

    private fun translate(e: BackendException): Exception = when (e.reason) {
        BackendException.Reason.VPN_NOT_AUTHORIZED -> PermissionNeededException()
        BackendException.Reason.UNABLE_TO_START_VPN ->
            InvalidConfigException("سرویس VPN شروع نشد. مجوز VPN را در تنظیمات اندروید بررسی کنید")
        BackendException.Reason.TUNNEL_MISSING_CONFIG ->
            InvalidConfigException("کانفیگ سرور ناقص است")
        BackendException.Reason.DNS_RESOLUTION_FAILURE ->
            InvalidConfigException("آدرس سرور قابل تبدیل نیست — DNS یا دامنه سرور را بررسی کنید")
        BackendException.Reason.WG_QUICK_CONFIG_ERROR_CODE ->
            InvalidConfigException("کلیدها یا ساختار کانفیگ نامعتبر است — کانفیگ را با سرور واقعی جایگزین کنید")
        BackendException.Reason.GO_ACTIVATION_ERROR_CODE ->
            InvalidConfigException("فعال‌سازی هسته WireGuard ناموفق بود — کانفیگ را بررسی کنید")
        BackendException.Reason.TUN_CREATION_ERROR ->
            InvalidConfigException("ساخت تونل VPN ناموفق بود — مجوز VPN را بررسی کنید")
        else -> InvalidConfigException("خطای هسته WireGuard: ${e.reason}")
    }
}
