package ir.ms7gurd.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import ir.ms7gurd.vpn.core.Consts
import ir.ms7gurd.vpn.data.SplitMode
import ir.ms7gurd.vpn.data.ThemeMode
import ir.ms7gurd.vpn.ui.MainViewModel
import ir.ms7gurd.vpn.ui.components.Ms7Card
import ir.ms7gurd.vpn.ui.components.Ms7Switch
import ir.ms7gurd.vpn.ui.components.SectionTitle
import ir.ms7gurd.vpn.ui.theme.Ms7Palette
import ir.ms7gurd.vpn.vpn.OpenVpnEngine
import ir.ms7gurd.vpn.vpn.XrayEngine

/**
 * صفحه تنظیمات — MS7 GURD (Developer: Mahdi Shahzaman)
 */
@Composable
fun SettingsScreen(vm: MainViewModel, onOpenSplitTunnel: () -> Unit) {
    val p = Ms7Palette
    val settings by vm.settings.collectAsState()
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showCores by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("تنظیمات", color = p.text, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(14.dp))

        // ---------------- اتصال ----------------
        SectionTitle("تنظیمات اتصال")
        Spacer(Modifier.height(8.dp))
        Ms7Card {
            SettingRow(Icons.Filled.Shield, "کیل‌سوئیچ", "اگر اتصال قطع شود، ترافیک اینترنت هم بسته می‌شود") {
                Ms7Switch(settings.killSwitch) { vm.setKillSwitch(it) }
            }
            Divider()
            SettingRow(Icons.Filled.PowerSettingsNew, "اتصال خودکار", "هنگام باز کردن اپ، به سرور آخر وصل شو") {
                Ms7Switch(settings.autoConnect) { vm.setAutoConnect(it) }
            }
            Divider()
            SettingRow(Icons.Filled.Notifications, "اعلان‌ها", "نمایش وضعیت اتصال در نوار اعلان") {
                Ms7Switch(settings.notifications) { vm.setNotifications(it) }
            }
            Divider()
            SettingRow(Icons.Filled.Apps, "تونل‌بندی تفکیکی", splitLabel(settings.splitMode)) {
                Text("مشاهده", color = p.teal, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable(onClick = onOpenSplitTunnel))
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---------------- ظاهر ----------------
        SectionTitle("ظاهر")
        Spacer(Modifier.height(8.dp))
        Ms7Card {
            SettingRow(Icons.Filled.DarkMode, "تم اپ", themeLabel(settings.themeMode)) {
                Text("تغییر", color = p.teal, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { showThemeDialog = true })
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---------------- درباره ----------------
        SectionTitle("درباره")
        Spacer(Modifier.height(8.dp))
        Ms7Card {
            SettingRow(Icons.Filled.Info, "درباره MS7 GURD", "نسخه ${Consts.VERSION} — توسعه‌دهنده: ${Consts.DEVELOPER}") {
                Text("نمایش", color = p.teal, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { showAbout = true })
            }
            Divider()
            SettingRow(Icons.Filled.Bolt, "وضعیت هسته‌ها", "WireGuard • Xray • OpenVPN") {
                Text("بررسی", color = p.teal, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { showCores = true })
            }
            Divider()
            SettingRow(Icons.Filled.HelpOutline, "راهنما و پشتیبانی", "سوالات رایج و تماس با ما") {
                Text("در تب پشتیبانی", color = p.textDim, style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "${Consts.APP_NAME} — ${Consts.TAGLINE}\nتوسعه‌دهنده: ${Consts.DEVELOPER}",
            color = p.textDim.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
        )
    }

    // دیالوگ تم
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("تم اپلیکیشن") },
            text = {
                Column {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.setTheme(mode); showThemeDialog = false }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(16.dp).clip(CircleShape).background(
                                    if (settings.themeMode == mode) p.teal else p.outline
                                )
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(mode.label, color = p.text, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showThemeDialog = false }) { Text("بستن") } },
        )
    }

    // دیالوگ درباره
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("درباره ${Consts.APP_NAME}") },
            text = {
                Column {
                    Text(
                        "${Consts.APP_NAME} — ${Consts.TAGLINE}",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "فیلترشکن امن و سریع با پشتیبانی از پروتکل‌های WireGuard، V2Ray/Xray و OpenVPN. " +
                            "تمرکز ما بر حریم خصوصی، سرعت بالا و تجربه کاربری ساده فارسی است.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("نسخه: ${Consts.VERSION}", style = MaterialTheme.typography.bodySmall)
                    Text("توسعه‌دهنده: ${Consts.DEVELOPER}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("عالی") } },
        )
    }

    // دیالوگ وضعیت هسته‌ها
    if (showCores) {
        val wgOk = true
        val xrayOk = XrayEngine.coreAvailable()
        val ovpnOk = OpenVpnEngine.coreAvailable()
        AlertDialog(
            onDismissRequest = { showCores = false },
            title = { Text("وضعیت هسته‌ها") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CoreStatus("WireGuard", true, "کاملاً فعال")
                    CoreStatus("V2Ray / Xray", xrayOk, if (xrayOk) "فعال" else "فایل libv2ray.aar را در app/libs قرار دهید (README بخش ۲)")
                    CoreStatus("OpenVPN", ovpnOk, if (ovpnOk) "فعال" else "فایل OpenVPNLibrary.aar را در app/libs قرار دهید (README بخش ۲)")
                }
            },
            confirmButton = { TextButton(onClick = { showCores = false }) { Text("فهمیدم") } },
        )
    }
}

@Composable
private fun CoreStatus(name: String, ok: Boolean, note: String) {
    val p = Ms7Palette
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) p.teal else p.gold))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(name, color = p.text, style = MaterialTheme.typography.titleSmall)
            Text(note, color = p.textDim, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String, trailing: @Composable () -> Unit) {
    val p = Ms7Palette
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(p.teal.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = p.teal, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = p.textDim, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.width(8.dp))
        trailing()
    }
}

@Composable
private fun Divider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .height(1.dp)
            .background(Ms7Palette.outline.copy(alpha = 0.4f))
    )
}

private fun splitLabel(mode: SplitMode): String = when (mode) {
    SplitMode.NONE -> "غیرفعال — همه اپ‌ها از VPN استفاده می‌کنند"
    SplitMode.ALLOW -> "فقط اپ‌های انتخابی"
    SplitMode.BLOCK -> "همه به‌جز انتخابی‌ها"
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "هماهنگ با سیستم"
    ThemeMode.DARK -> "تیره"
    ThemeMode.LIGHT -> "روشن"
}
