package ir.ms7gurd.vpn.data

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.StringReader

/**
 * تشخیص و پارس همه نوع کانفیگ — MS7 GURD (Developer: Mahdi Shahzaman)
 * پشتیبانی: WireGuard (wg-quick) ، VLESS ، VMess ، Trojan ، Shadowsocks ، OpenVPN (.ovpn)
 */
object ConfigImporter {

    enum class Type(val label: String) {
        WIREGUARD("WireGuard"),
        VLESS("VLESS / Xray"),
        VMESS("VMess / Xray"),
        TROJAN("Trojan / Xray"),
        SHADOWSOCKS("Shadowsocks / Xray"),
        OPENVPN("OpenVPN"),
        SUBSCRIPTION("سابسکریپشن"),
        UNKNOWN("نامشخص");
    }

    /** نتیجه تشخیص برای نمایش در UI */
    fun detect(text: String): Type {
        val t = text.trim()
        return when {
            t.startsWith("vless://", true) -> Type.VLESS
            t.startsWith("vmess://", true) -> Type.VMESS
            t.startsWith("trojan://", true) || t.startsWith("trojan-go://", true) -> Type.TROJAN
            t.startsWith("ss://", true) || t.startsWith("ssr://", true) -> Type.SHADOWSOCKS
            t.contains("[Interface]", true) && t.contains("[Peer]", true) -> Type.WIREGUARD
            t.contains("<ca>", true) || t.contains("client", true) && t.contains("remote ", true) && t.contains("proto ", true) -> Type.OPENVPN
            else -> Type.UNKNOWN
        }
    }

    /**
     * ورودی می‌تواند باشد: یک کانفیگ، چند خط کانفیگ، یا base64 سابسکریپشن.
     * خروجی: لیست سرورهای قابل ذخیره
     */
    fun parseMany(text: String): Pair<Type, List<Server>> {
        val t = text.trim()
        // ۰) JSON (خروجی Cloudflare Worker یا هاست اختصاصی خودتان)
        if (t.startsWith("{")) {
            try {
                val o = JSONObject(t)
                val arr = o.optJSONArray("servers") ?: o.optJSONArray("configs")
                    ?: o.optJSONArray("items") ?: o.optJSONArray("links")
                if (arr != null && arr.length() > 0) {
                    val servers = ArrayList<Server>()
                    for (i in 0 until arr.length()) {
                        try {
                            val item = arr.get(i)
                            if (item is String) {
                                parseOne(item)?.let { servers.add(it) }
                            } else if (item is JSONObject) {
                                val uri = item.optString("uri", item.optString("link", item.optString("config", "")))
                                if (uri.isNotBlank()) {
                                    parseOne(uri)?.let { base ->
                                        servers.add(base.copy(
                                            name = item.optString("name", base.name).ifBlank { base.name },
                                            city = item.optString("city", base.city),
                                            country = item.optString("countryText", base.country),
                                            countryCode = item.optString("countryCode", item.optString("country", base.countryCode)).uppercase(),
                                            premium = item.optBoolean("premium", base.premium),
                                            badge = item.optString("badge", "").ifBlank { null },
                                        ))
                                    }
                                }
                            }
                        } catch (e: Exception) { /* این آیتم نامعتبر بود — ادامه */ }
                    }
                    if (servers.isNotEmpty()) return Type.SUBSCRIPTION to servers
                }
            } catch (e: Exception) { /* JSON معتبر نبود — روش‌های بعدی */ }
        }
        // ۱) سابسکریپشن base64
        if (!t.contains("[Interface]") && !t.startsWith("vless") && !t.startsWith("vmess") &&
            !t.startsWith("trojan") && !t.startsWith("ss") && looksLikeBase64(t)
        ) {
            val decoded = try {
                String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
            } catch (e: Exception) { t }
            val lines = decoded.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val servers = lines.mapNotNull { line -> parseOne(line) }
            if (servers.isNotEmpty()) return Type.SUBSCRIPTION to servers
        }
        // ۲) چند خطی (هر خط یک لینک)
        val lines = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size > 1 && lines.all { it.startsWith("vless", true) || it.startsWith("vmess", true) || it.startsWith("trojan", true) || it.startsWith("ss", true) }) {
            val servers = lines.mapNotNull { parseOne(it) }
            if (servers.isNotEmpty()) return Type.SUBSCRIPTION to servers
        }
        // ۳) تک کانفیگ
        val one = parseOne(t) ?: throw IllegalArgumentException("کانفیگ قابل تشخیص نیست. لطفاً متن کانفیگ را کامل کپی کنید.")
        return detect(t) to listOf(one)
    }

    private fun looksLikeBase64(t: String): Boolean =
        t.replace("\n", "").replace("\r", "").matches(Regex("^[A-Za-z0-9+/=]{40,}$"))

    private fun parseOne(text: String): Server? {
        val t = text.trim()
        return try {
            when {
                t.startsWith("vless://", true) -> parseVless(t)
                t.startsWith("vmess://", true) -> parseVmess(t)
                t.startsWith("trojan://", true) -> parseTrojan(t)
                t.startsWith("ss://", true) -> parseSs(t)
                t.contains("[Interface]", true) -> parseWg(t)
                t.contains("<ca>", true) || (t.contains("remote ", true) && t.contains("<key>", true)) -> parseOvpn(t)
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- WireGuard ----------
    private fun parseWg(text: String): Server {
        // اعتبارسنجی با کتابخانه رسمی
        val cfg = com.wireguard.config.Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
        val endpoint = cfg.peers.firstOrNull()?.endpoint?.orElse(null)?.toString() ?: "0.0.0.0"
        val host = endpoint.substringBefore(":")
        val name = hostOrNull(host) ?: "سرور WireGuard"
        return Server(
            id = "wg-${host.replace('.', '-')}-${System.currentTimeMillis() % 100000}",
            name = name,
            city = "",
            country = "",
            countryCode = "XX",
            protocol = Protocol.WIREGUARD,
            premium = false,
            config = text.trim(),
        )
    }

    private fun hostOrNull(host: String): String? {
        val map = mapOf(
            "de" to "آلمان", "nl" to "هلند", "us" to "آمریکا", "uk" to "انگلستان", "tr" to "ترکیه",
            "fi" to "فنلاند", "ae" to "امارات", "fr" to "فرانسه", "sg" to "سنگاپور", "jp" to "ژاپن",
        )
        val cc = host.substringBeforeLast('.').substringAfterLast('.').lowercase()
        return map[cc]?.let { "$it (${host})" } ?: "سرور WireGuard ($host)"
    }

    // ---------- VLESS ----------
    private fun parseVless(link: String): Server {
        val uri = java.net.URI(link.replace(" ", "%20"))
        val uuid = uri.userInfo ?: throw IllegalArgumentException("UUID نامعتبر")
        val host = uri.host ?: ""
        val port = if (uri.port > 0) uri.port else 443
        val q = parseQuery(uri.rawQuery ?: "")
        val sni = q["sni"] ?: q["host"] ?: host
        val name = java.net.URLDecoder.decode(uri.fragment ?: "$host:$port", "UTF-8")
        return Server(
            id = "vl-$host-$port-${System.currentTimeMillis() % 100000}",
            name = name.ifBlank { "سرور VLESS ($host)" },
            city = "", country = "", countryCode = ccOf(host),
            protocol = Protocol.XRAY, premium = false,
            config = link.trim(),
        ).let { it }
    }

    // ---------- VMess ----------
    private fun parseVmess(link: String): Server {
        val b64 = link.removePrefix("vmess://").trim()
        val json = try {
            String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8)
        } catch (e: Exception) { throw IllegalArgumentException("لینک VMess نامعتبر است") }
        val o = JSONObject(json)
        val host = o.optString("add", "")
        val port = o.optInt("port", 443)
        val name = o.optString("ps", "سرور VMess")
        return Server(
            id = "vm-$host-$port-${System.currentTimeMillis() % 100000}",
            name = name.ifBlank { "سرور VMess ($host)" },
            city = "", country = "", countryCode = ccOf(host),
            protocol = Protocol.XRAY, premium = false,
            config = link.trim(),
        )
    }

    // ---------- Trojan ----------
    private fun parseTrojan(link: String): Server {
        val uri = java.net.URI(link)
        val host = uri.host ?: ""
        val port = if (uri.port > 0) uri.port else 443
        val q = parseQuery(uri.rawQuery ?: "")
        val name = java.net.URLDecoder.decode(uri.fragment ?: "سرور Trojan", "UTF-8")
        return Server(
            id = "tr-$host-$port-${System.currentTimeMillis() % 100000}",
            name = name.ifBlank { "سرور Trojan ($host)" },
            city = "", country = "", countryCode = ccOf(host),
            protocol = Protocol.XRAY, premium = false,
            config = link.trim(),
        )
    }

    // ---------- Shadowsocks ----------
    private fun parseSs(link: String): Server {
        val body = link.removePrefix("ss://").substringBefore("#")
        val frag = link.substringAfter("#", "").let { java.net.URLDecoder.decode(it, "UTF-8") }
        val hostPort: String
        if (body.contains("@")) {
            hostPort = body.substringAfter("@")
        } else {
            val decoded = String(Base64.decode(body, Base64.DEFAULT), Charsets.UTF_8)
            hostPort = decoded.substringAfter("@")
        }
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443
        return Server(
            id = "ss-$host-$port-${System.currentTimeMillis() % 100000}",
            name = frag.ifBlank { "سرور Shadowsocks ($host)" },
            city = "", country = "", countryCode = ccOf(host),
            protocol = Protocol.XRAY, premium = false,
            config = link.trim(),
        )
    }

    // ---------- OpenVPN ----------
    private fun parseOvpn(text: String): Server {
        val remote = Regex("remote\\s+([\\w.\\-]+)\\s+(\\d+)", RegexOption.IGNORE_CASE).find(text)
        val host = remote?.groupValues?.get(1) ?: "openvpn"
        val port = remote?.groupValues?.get(2) ?: "1194"
        return Server(
            id = "ov-$host-$port-${System.currentTimeMillis() % 100000}",
            name = "سرور OpenVPN ($host)",
            city = "", country = "", countryCode = ccOf(host),
            protocol = Protocol.OPENVPN, premium = false,
            config = text.trim(),
        )
    }

    // ---------- helpers ----------
    private fun parseQuery(q: String): Map<String, String> =
        q.split("&").filter { it.contains("=") }.associate {
            val k = it.substringBefore("=")
            val v = java.net.URLDecoder.decode(it.substringAfter("="), "UTF-8")
            k to v
        }

    private fun ccOf(host: String): String {
        val tld = host.substringBeforeLast('.').substringAfterLast('.').lowercase()
        return when (tld) {
            "de" -> "DE"; "nl" -> "NL"; "us" -> "US"; "uk" -> "UK"; "tr" -> "TR"
            "fi" -> "FI"; "ae" -> "AE"; "fr" -> "FR"; "sg" -> "SG"; "jp" -> "JP"
            "ca" -> "CA"; "in" -> "IN"; "ru" -> "RU"; "au" -> "AU"
            else -> "XX"
        }
    }

    /** ساخت JSON کامل Xray از لینک (الگوی v2rayNG) */
    fun buildXrayJson(link: String): String {
        val t = link.trim()
        return when {
            t.startsWith("vless://", true) -> vlessJson(t)
            t.startsWith("vmess://", true) -> vmessJson(t)
            t.startsWith("trojan://", true) -> trojanJson(t)
            t.startsWith("ss://", true) -> ssJson(t)
            else -> throw IllegalArgumentException("پروتکل این کانفیگ برای Xray قابل تبدیل نیست")
        }
    }

    private fun baseTemplate(outbound: JSONObject): String {
        val conf = JSONObject()
        conf.put("log", JSONObject().put("loglevel", "warning"))

        val inbound = JSONObject()
            .put("tag", "socks-in")
            .put("port", 10808)
            .put("listen", "127.0.0.1")
            .put("protocol", "socks")
            .put("settings", JSONObject().put("auth", "noauth").put("udp", true).put("userLevel", 8))
            .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray(listOf("http", "tls"))).put("routeOnly", false))
        conf.put("inbounds", JSONArray(listOf(inbound)))

        conf.put("outbounds", JSONArray(listOf(outbound,
            JSONObject().put("tag", "direct").put("protocol", "freedom").put("settings", JSONObject()),
            JSONObject().put("tag", "block").put("protocol", "blackhole").put("settings", JSONObject().put("response", JSONObject().put("type", "http")))
        )))

        val routing = JSONObject()
        routing.put("domainStrategy", "IPIfNonMatch")
        routing.put("rules", JSONArray(listOf(
            // آی‌پی‌های محلی مستقیم بروند (دسترسی به LAN حفظ شود)
            JSONObject().put("type", "field").put("ip", JSONArray(listOf("geoip:private"))).put("outboundTag", "direct"),
        )))
        conf.put("routing", routing)

        conf.put("dns", JSONObject()
            .put("servers", JSONArray(listOf("1.1.1.1", "8.8.8.8", "localhost")))
            .put("queryStrategy", "UseIP"))

        // آمار ترافیک (برای نمایش دانلود/آپلود در اپ) — الگوی v2rayNG
        conf.put("stats", JSONObject())
        conf.put("policy", JSONObject()
            .put("levels", JSONObject().put("8", JSONObject()
                .put("handshake", 4).put("connIdle", 300)
                .put("uplinkOnly", 0).put("downlinkOnly", 0)
                .put("statsUserUplink", true).put("statsUserDownlink", true)
                .put("bufferSize", 0)))
            .put("system", JSONObject()
                .put("statsOutboundUplink", true).put("statsOutboundDownlink", true)))
        return conf.toString()
    }

    private fun streamSettings(q: Map<String, String>, host: String): JSONObject {
        val ss = JSONObject()
        val security = q["security"] ?: if (q["type"] == "ws" && (q["host"]?.isNotBlank() == true)) "tls" else "none"
        ss.put("network", q["type"] ?: "tcp")
        when (security) {
            "tls" -> {
                val tls = JSONObject()
                tls.put("enabled", true)
                tls.put("serverName", q["sni"] ?: q["host"] ?: host)
                q["fp"]?.let { tls.put("fingerprint", it) }
                tls.put("allowInsecure", false)
                q["alpn"]?.let { tls.put("alpn", JSONArray(it.split(",").map { a -> a.trim() })) }
                ss.put("tlsSettings", tls)
            }
            "reality" -> {
                val r = JSONObject()
                r.put("enabled", true)
                r.put("serverName", q["sni"] ?: host)
                q["fp"]?.let { r.put("fingerprint", it) }
                r.put("publicKey", q["pbk"] ?: "")
                r.put("shortId", q["sid"] ?: "")
                r.put("spiderX", q["spx"] ?: "")
                ss.put("realitySettings", r)
            }
        }
        when (q["type"]) {
            "ws" -> {
                val ws = JSONObject()
                ws.put("path", q["path"] ?: "/")
                val headers = JSONObject()
                (q["host"] ?: host).takeIf { it.isNotBlank() }?.let { headers.put("Host", it) }
                ws.put("headers", headers)
                ss.put("wsSettings", ws)
            }
            "grpc" -> {
                ss.put("grpcSettings", JSONObject().put("serviceName", q["serviceName"] ?: q["path"] ?: ""))
            }
            "http", "h2" -> {
                ss.put("httpSettings", JSONObject().put("host", JSONArray(listOf(q["host"] ?: host))).put("path", q["path"] ?: "/"))
            }
        }
        return ss
    }

    private fun vlessJson(link: String): String {
        val uri = java.net.URI(link.replace(" ", "%20"))
        val q = parseQuery(uri.rawQuery ?: "")
        val ob = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "vless")
            .put("settings", JSONObject()
                .put("vnext", JSONArray(listOf(
                    JSONObject()
                        .put("address", uri.host)
                        .put("port", if (uri.port > 0) uri.port else 443)
                        .put("users", JSONArray(listOf(
                            JSONObject()
                                .put("id", uri.userInfo ?: "")
                                .put("encryption", "none")
                                .put("flow", q["flow"] ?: "")
                                .put("level", 8)
                        )))
                )))
            )
        ob.put("streamSettings", streamSettings(q, uri.host ?: ""))
        ob.put("mux", JSONObject().put("enabled", false).put("concurrency", -1))
        return baseTemplate(ob)
    }

    private fun vmessJson(link: String): String {
        val o = JSONObject(String(Base64.decode(link.removePrefix("vmess://").trim(), Base64.DEFAULT), Charsets.UTF_8))
        val q = mapOf(
            "type" to o.optString("net", "tcp"),
            "security" to (o.optString("tls", "").ifBlank { "none" }),
            "sni" to o.optString("sni", ""),
            "host" to o.optString("host", ""),
            "path" to o.optString("path", "/"),
            "fp" to o.optString("fp", ""),
        )
        val ob = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "vmess")
            .put("settings", JSONObject()
                .put("vnext", JSONArray(listOf(
                    JSONObject()
                        .put("address", o.optString("add", ""))
                        .put("port", o.optInt("port", 443))
                        .put("users", JSONArray(listOf(
                            JSONObject()
                                .put("id", o.optString("id", ""))
                                .put("alterId", o.optInt("aid", 0))
                                .put("security", o.optString("scy", "auto"))
                                .put("level", 8)
                        )))
                )))
            )
        ob.put("streamSettings", streamSettings(q, o.optString("add", "")))
        ob.put("mux", JSONObject().put("enabled", false).put("concurrency", -1))
        return baseTemplate(ob)
    }

    private fun trojanJson(link: String): String {
        val uri = java.net.URI(link)
        val q = parseQuery(uri.rawQuery ?: "")
        val ob = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "trojan")
            .put("settings", JSONObject()
                .put("servers", JSONArray(listOf(
                    JSONObject()
                        .put("address", uri.host)
                        .put("port", if (uri.port > 0) uri.port else 443)
                        .put("password", uri.userInfo ?: "")
                        .put("level", 8)
                )))
            )
        val q2 = q + mapOf("security" to "tls")
        ob.put("streamSettings", streamSettings(q2, uri.host ?: ""))
        return baseTemplate(ob)
    }

    private fun ssJson(link: String): String {
        val body = link.removePrefix("ss://").substringBefore("#").substringBefore("?")
        val decoded: String = if (body.contains("@")) body
        else String(Base64.decode(body, Base64.DEFAULT), Charsets.UTF_8)
        val userinfo = decoded.substringBefore("@")
        val hostPort = decoded.substringAfter("@")
        val method = java.net.URLDecoder.decode(userinfo.substringBefore(":"), "UTF-8")
        val password = java.net.URLDecoder.decode(userinfo.substringAfter(":"), "UTF-8")
        val ob = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "shadowsocks")
            .put("settings", JSONObject()
                .put("servers", JSONArray(listOf(
                    JSONObject()
                        .put("address", hostPort.substringBeforeLast(":"))
                        .put("port", hostPort.substringAfterLast(":").toIntOrNull() ?: 443)
                        .put("method", method)
                        .put("password", password)
                        .put("level", 8)
                )))
            )
        return baseTemplate(ob)
    }
}
