package ir.ms7gurd.vpn.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.ms7gurd.vpn.MS7App
import ir.ms7gurd.vpn.core.Fa
import ir.ms7gurd.vpn.data.Activation
import ir.ms7gurd.vpn.data.AppSettings
import ir.ms7gurd.vpn.data.ConnState
import ir.ms7gurd.vpn.data.SplitConfig
import ir.ms7gurd.vpn.data.SplitMode
import ir.ms7gurd.vpn.data.Server
import ir.ms7gurd.vpn.data.ThemeMode
import ir.ms7gurd.vpn.data.ConfigImporter
import ir.ms7gurd.vpn.vpn.ConnectionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.time.LocalDate

/**
 * ViewModel اصلی — MS7 GURD (Developer: Mahdi Shahzaman)
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val settingsStore = (app as MS7App).settingsStore
    private val serverStore = (app as MS7App).serverStore

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val servers: StateFlow<List<Server>> = serverStore.servers
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val connState = ConnectionManager.state

    val premiumActive: StateFlow<Boolean> = settings.map { s ->
        s.premiumUntilEpochDay > LocalDate.now().toEpochDay()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val premiumUntilText: StateFlow<String> = settings.map { s ->
        if (s.premiumUntilEpochDay > 0) Fa.date(s.premiumUntilEpochDay) else ""
    }.stateIn(viewModelScope, SharingStarted.Eagerly, "")

    /** سرور در انتظار مجوز VPN */
    var permissionPendingServer: Server? = null

    /** پیام‌های یک‌بارمصرف برای Snackbar */
    val snackbar = MutableStateFlow<String?>(null)

    /** نتیجه اسکن QR برای صفحه افزودن کانفیگ */
    val qrResult = MutableStateFlow<String?>(null)

    /** اینتنت مجوز VPN در انتظار پاسخ کاربر */
    val vpnRequest = MutableStateFlow<android.content.Intent?>(null)

    /** حالت تست پینگ */
    val pinging = MutableStateFlow(false)

    init {
        // همگام‌سازی تنظیمات runtime
        viewModelScope.launch {
            settings.collect {
                ConnectionManager.killSwitchEnabled = it.killSwitch
                ConnectionManager.notificationsEnabled = it.notifications
            }
        }
        // اتصال خودکار هنگام باز شدن اپ
        viewModelScope.launch {
            val s = settings.first()
            if (s.autoConnect && s.selectedServerId.isNotBlank()) {
                kotlinx.coroutines.delay(1200)
                val server = servers.first().firstOrNull { it.id == s.selectedServerId }
                if (server != null && connState.value.state == ConnState.DISCONNECTED) {
                    tryConnect(server, silent = true)
                }
            }
        }
    }

    // ------------------------------------------------ اتصال
    fun toggleConnection() {
        val current = connState.value
        when (current.state) {
            ConnState.CONNECTED, ConnState.CONNECTING -> disconnect()
            else -> {
                val server = servers.value.firstOrNull { it.id == settings.value.selectedServerId }
                    ?: servers.value.firstOrNull()
                if (server == null) snackbar.value = "اول یک سرور اضافه یا انتخاب کنید"
                else tryConnect(server)
            }
        }
    }

    fun tryConnect(server: Server, silent: Boolean = false) {
        viewModelScope.launch {
            if (server.premium && !premiumActive.value) {
                if (!silent) snackbar.value = "این سرور مخصوص اعضای پرمیوم است — از تب پرمیوم فعال کنید"
                return@launch
            }
            settingsStore.setSelectedServer(server.id)

            // چک مجوز VPN قبل از شروع
            if (server.protocol != ir.ms7gurd.vpn.data.Protocol.OPENVPN) {
                val prep = android.net.VpnService.prepare(getApplication())
                if (prep != null) {
                    vpnRequest.value = prep
                    return@launch
                }
            }

            val s = settings.first()
            when (ConnectionManager.connect(getApplication(), server, SplitConfig(s.splitMode, s.splitApps))) {
                ConnectionManager.Outcome.NEED_PERMISSION -> {
                    val prep = android.net.VpnService.prepare(getApplication())
                    if (prep != null) vpnRequest.value = prep
                }
                ConnectionManager.Outcome.ERROR -> {
                    if (!silent) snackbar.value = connState.value.message ?: "اتصال ناموفق بود"
                }
                ConnectionManager.Outcome.STARTED -> {}
            }
        }
    }

    fun clearVpnRequest() { vpnRequest.value = null }

    fun onVpnPermissionResult() {
        val server = permissionPendingServer
        permissionPendingServer = null
        if (server != null) tryConnect(server, silent = true)
    }

    fun disconnect() {
        viewModelScope.launch { ConnectionManager.disconnect(getApplication()) }
    }

    /** انتخاب سرور = ذخیره + اتصال فوری */
    fun selectServer(server: Server) = tryConnect(server)

    // ------------------------------------------------ سرورها
    fun addServers(list: List<Server>) {
        viewModelScope.launch {
            serverStore.addAll(list)
            snackbar.value = "${Fa.num(list.size)} کانفیگ اضافه شد"
        }
    }

    fun deleteServer(server: Server) {
        viewModelScope.launch {
            serverStore.delete(server.id)
            if (settings.value.selectedServerId == server.id) {
                settingsStore.setSelectedServer("")
            }
            snackbar.value = "سرور حذف شد"
        }
    }

    // ------------------------------------------------ سابسکریپشن
    fun fetchSubscription(url: String) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 12000
                    conn.setRequestProperty("User-Agent", "MS7-GURD/1.0")
                    conn.instanceFollowRedirects = true
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    body
                }
                val (_, servers) = ConfigImporter.parseMany(text)
                if (servers.isEmpty()) {
                    snackbar.value = "هیچ کانفیگی در سابسکریپشن پیدا نشد"
                } else {
                    serverStore.addAll(servers)
                    snackbar.value = "${Fa.num(servers.size)} سرور از سابسکریپشن اضافه شد"
                }
            } catch (e: Exception) {
                snackbar.value = "دریافت سابسکریپشن ناموفق بود — لینک و اینترنت را بررسی کنید"
            }
        }
    }

    fun pingAll() {
        if (pinging.value) return
        viewModelScope.launch {
            pinging.value = true
            val list = servers.value
            val results = list.map { server ->
                async(Dispatchers.IO) {
                    server.id to tcpPing(extractHost(server), extractPort(server))
                }
            }.awaitAll().toMap()
            pingResults.value = pingResults.value + results.mapNotNull { (k, v) -> v?.let { k to it } }
            pinging.value = false
            snackbar.value = "تست پینگ انجام شد"
        }
    }

    /** نتایج تست پینگ (سرور id → میلی‌ثانیه) */
    val pingResults = MutableStateFlow<Map<String, Int>>(emptyMap())

    fun pingOf(server: Server): Int? = pingResults.value[server.id] ?: server.pingMs

    private fun extractHost(server: Server): String = try {
        when (server.protocol) {
            ir.ms7gurd.vpn.data.Protocol.WIREGUARD -> {
                Regex("Endpoint\\s*=\\s*([^:]+)", RegexOption.IGNORE_CASE).find(server.config)?.groupValues?.get(1)?.trim() ?: ""
            }
            ir.ms7gurd.vpn.data.Protocol.XRAY -> {
                val t = server.config
                when {
                    t.startsWith("vmess", true) -> {
                        val json = String(android.util.Base64.decode(t.removePrefix("vmess://"), android.util.Base64.DEFAULT), Charsets.UTF_8)
                        org.json.JSONObject(json).optString("add", "")
                    }
                    else -> java.net.URI(t).host ?: ""
                }
            }
            else -> Regex("remote\\s+([\\w.\\-]+)", RegexOption.IGNORE_CASE).find(server.config)?.groupValues?.get(1) ?: ""
        }
    } catch (e: Exception) {
        ""
    }

    private fun extractPort(server: Server): Int = try {
        when (server.protocol) {
            ir.ms7gurd.vpn.data.Protocol.WIREGUARD -> {
                Regex("Endpoint\\s*=[^:]*:(\\d+)", RegexOption.IGNORE_CASE).find(server.config)?.groupValues?.get(1)?.toInt() ?: 51820
            }
            ir.ms7gurd.vpn.data.Protocol.XRAY -> {
                val t = server.config
                when {
                    t.startsWith("vmess", true) -> {
                        val json = String(android.util.Base64.decode(t.removePrefix("vmess://"), android.util.Base64.DEFAULT), Charsets.UTF_8)
                        org.json.JSONObject(json).optInt("port", 443)
                    }
                    else -> java.net.URI(t).port.takeIf { it > 0 } ?: 443
                }
            }
            else -> Regex("remote\\s+[\\w.\\-]+\\s+(\\d+)", RegexOption.IGNORE_CASE).find(server.config)?.groupValues?.get(1)?.toInt() ?: 1194
        }
    } catch (e: Exception) {
        443
    }

    private fun tcpPing(host: String, port: Int): Int? {
        if (host.isBlank()) return null
        return try {
            val start = System.currentTimeMillis()
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), 2000)
                (System.currentTimeMillis() - start).toInt().coerceAtLeast(1)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------ پرمیوم
    fun activateCode(code: String): Activation.Result {
        val r = Activation.validate(code)
        if (r is Activation.Result.Success) {
            viewModelScope.launch {
                settingsStore.activatePremium(r.days, r.planName)
                snackbar.value = "پرمیوم فعال شد — ${r.planName}"
            }
        }
        return r
    }

    // ------------------------------------------------ تنظیمات
    fun setTheme(mode: ThemeMode) = viewModelScope.launch { settingsStore.setTheme(mode) }
    fun setAutoConnect(v: Boolean) = viewModelScope.launch { settingsStore.setAutoConnect(v) }
    fun setKillSwitch(v: Boolean) = viewModelScope.launch { settingsStore.setKillSwitch(v) }
    fun setNotifications(v: Boolean) = viewModelScope.launch { settingsStore.setNotifications(v) }
    fun setSplitMode(mode: SplitMode) = viewModelScope.launch { settingsStore.setSplitMode(mode) }
    fun setSplitApps(apps: Set<String>) = viewModelScope.launch { settingsStore.setSplitApps(apps) }

    fun clearSnackbar() { snackbar.value = null }
    fun clearQrResult() { qrResult.value = null }
}
