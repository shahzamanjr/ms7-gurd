pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // اگر فایل libv2ray.aar را در app/libs قرار دهید نیازی به مخزن اضافه نیست
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "MS7-GURD"
include(":app")
